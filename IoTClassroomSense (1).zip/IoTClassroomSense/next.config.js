/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  async rewrites() {
    return [
      {
        // Rewrite API requests to Flask backend
        source: '/api/:path*',
        destination: process.env.BACKEND_URL || 'http://localhost:5000/api/:path*',
      },
    ];
  },
  // Add Indian Rupee currency symbol support
  i18n: {
    locales: ['en-IN'],
    defaultLocale: 'en-IN',
  },
};

module.exports = nextConfig;