import React from 'react';
import { 
  Box, 
  Typography, 
  CircularProgress
} from '@mui/material';

const SensorGauge = ({ 
  icon: Icon, 
  title, 
  value, 
  unit, 
  min, 
  max, 
  lowThreshold, 
  highThreshold,
  iconColor,
  formatValue = (v) => v.toFixed(1),
  getStatusText = () => ''
}) => {
  // Calculate percentage for the gauge (between 0-100)
  const percentage = Math.min(Math.max(((value - min) / (max - min)) * 100, 0), 100);
  
  // Determine color based on thresholds
  const getColor = () => {
    if (value > highThreshold) return 'error.main';
    if (value < lowThreshold) return 'warning.main';
    return 'success.main';
  };
  
  // Get status text based on value
  const statusText = getStatusText(value);
  
  return (
    <Box className="sensor-reading">
      <Icon sx={{ color: iconColor, fontSize: 40, mb: 1 }} />
      <Typography variant="h6" gutterBottom>{title}</Typography>
      <Box sx={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <CircularProgress 
          variant="determinate" 
          value={percentage} 
          size={120}
          thickness={5}
          sx={{ 
            color: getColor(),
            position: 'absolute'
          }}
        />
        <CircularProgress 
          variant="determinate" 
          value={100} 
          size={120}
          thickness={5}
          sx={{ 
            color: 'grey.300',
            position: 'absolute',
            opacity: 0.3
          }}
        />
        <Box sx={{ position: 'absolute', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <Typography variant="h4" component="div">
            {formatValue(value)}
          </Typography>
          <Typography variant="caption" component="div" color="text.secondary">
            {unit}
          </Typography>
        </Box>
      </Box>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
        {statusText}
      </Typography>
    </Box>
  );
};

export default SensorGauge;