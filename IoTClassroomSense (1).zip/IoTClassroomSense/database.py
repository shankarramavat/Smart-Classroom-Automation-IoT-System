# This file is kept for backward compatibility
# but all database functionality has been moved to app.py

# Import db and Base from app
from app import db, Base

# For backward compatibility
def init_db(app):
    """
    This function is kept for backward compatibility.
    The actual database initialization is now handled in app.py
    """
    pass