import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, ForeignKey, Text
from sqlalchemy.orm import relationship

# Import db from app
from app import db

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(64), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(256), nullable=False)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    last_login = Column(DateTime, nullable=True)

    def set_password(self, password):
        """Set password hash for user."""
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        """Check if password is correct."""
        return check_password_hash(self.password_hash, password)
        
    def __repr__(self):
        return f'<User {self.username}>'

class SystemState(db.Model):
    __tablename__ = 'system_state'
    
    id = Column(Integer, primary_key=True)
    lights_on = Column(Boolean, default=False)
    ac_on = Column(Boolean, default=False)
    fan_on = Column(Boolean, default=False)
    is_occupied = Column(Boolean, default=False)
    temperature = Column(Float, default=22.0)  # in Celsius
    humidity = Column(Float, default=45.0)     # in percentage
    motion_detected = Column(Boolean, default=False)
    lights_override = Column(Boolean, default=False)
    ac_override = Column(Boolean, default=False)
    fan_override = Column(Boolean, default=False)
    energy_saved = Column(Float, default=0.0)  # in kWh
    cost_saved = Column(Float, default=0.0)    # in INR (₹)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    def __repr__(self):
        return f'<SystemState {self.id} - occupied: {self.is_occupied}>'

class Log(db.Model):
    __tablename__ = 'logs'
    
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    event_type = Column(String(50), nullable=False)
    device = Column(String(50), nullable=True)
    details = Column(Text, nullable=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    
    user = relationship('User', backref='logs')
    
    def __repr__(self):
        return f'<Log {self.id} - {self.event_type}>'

class Sensor(db.Model):
    __tablename__ = 'sensors'
    
    id = Column(Integer, primary_key=True)
    sensor_id = Column(String(50), unique=True, nullable=False)
    sensor_type = Column(String(50), nullable=False)
    location = Column(String(100), nullable=False)
    ip_address = Column(String(50), nullable=True)
    status = Column(String(20), default='offline')
    last_reading = Column(Float, nullable=True)
    last_reading_unit = Column(String(10), nullable=True)
    last_updated = Column(DateTime, nullable=True)
    
    def __repr__(self):
        return f'<Sensor {self.sensor_id} - {self.sensor_type}>'