import datetime

def register_filters(app):
    """Register custom template filters with the Flask app."""
    
    @app.template_filter('timestamp_to_date')
    def timestamp_to_date(timestamp):
        """Convert timestamp to formatted date."""
        if not timestamp:
            return "N/A"
        if isinstance(timestamp, datetime.datetime):
            return timestamp.strftime('%Y-%m-%d')
        return timestamp
    
    @app.template_filter('timestamp_to_time')
    def timestamp_to_time(timestamp):
        """Convert timestamp to formatted time."""
        if not timestamp:
            return "N/A"
        if isinstance(timestamp, datetime.datetime):
            return timestamp.strftime('%H:%M:%S')
        return timestamp
    
    @app.template_filter('timestamp_to_relative')
    def timestamp_to_relative(timestamp):
        """Convert timestamp to relative time (e.g., "2 hours ago")."""
        if not timestamp:
            return "N/A"
        
        if not isinstance(timestamp, datetime.datetime):
            return timestamp
            
        now = datetime.datetime.utcnow()
        diff = now - timestamp
        
        seconds = diff.total_seconds()
        
        if seconds < 60:
            return "Just now"
        elif seconds < 3600:
            minutes = int(seconds / 60)
            return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
        elif seconds < 86400:
            hours = int(seconds / 3600)
            return f"{hours} hour{'s' if hours != 1 else ''} ago"
        elif seconds < 604800:
            days = int(seconds / 86400)
            return f"{days} day{'s' if days != 1 else ''} ago"
        else:
            return timestamp.strftime('%Y-%m-%d')