import threading
import time
import random
import logging
try:
    import numpy as np
except ImportError:
    # Mock numpy for environments where it's not available
    class NumpyMock:
        def zeros(self, shape, dtype=None):
            return [[0 for _ in range(shape[1])] for _ in range(shape[0])]
        
        def ones(self, shape, dtype=None):
            return [[1 for _ in range(shape[1])] for _ in range(shape[0])]
        
        def uint8(self):
            return 'uint8'
    
    np = NumpyMock()

try:
    import cv2
except ImportError:
    # Mock cv2 for environments where it's not available
    cv2 = None

logger = logging.getLogger(__name__)

class CameraSimulation(threading.Thread):
    """
    Simulates a camera that provides frames for the person detection system.
    For Replit testing, this cycles between empty and occupied classroom images.
    """
    
    def __init__(self, interval=0.1):
        """
        Initialize the camera simulation.
        
        Args:
            interval: How often to update the frame in seconds
        """
        threading.Thread.__init__(self)
        self.daemon = True
        self.interval = interval
        self.running = False
        self.frame = self._create_default_empty_frame()
        self.mode = 3  # 0 = random, 1 = always empty, 2 = always occupied, 3 = alternating
        self.frame_count = 0
        self.alternating_period = 100  # Frames to wait before switching in alternating mode
    
    def _create_default_empty_frame(self):
        """Create a default empty classroom frame."""
        # Create a black image
        frame = np.zeros((480, 640, 3), dtype=np.uint8)
        
        # Add some basic classroom features (whiteboard, desks)
        # Whiteboard
        cv2.rectangle(frame, (50, 50), (590, 150), (200, 200, 200), -1)
        cv2.rectangle(frame, (50, 50), (590, 150), (100, 100, 100), 2)
        
        # Desks
        for row in range(3):
            for col in range(4):
                x = 100 + col * 120
                y = 200 + row * 80
                cv2.rectangle(frame, (x, y), (x + 100, y + 50), (120, 80, 50), -1)
                cv2.rectangle(frame, (x, y), (x + 100, y + 50), (80, 40, 20), 2)
        
        # Add text
        cv2.putText(frame, "EMPTY CLASSROOM", (180, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                    1, (255, 255, 255), 2)
        
        return frame
    
    def _create_default_occupied_frame(self):
        """Create a default occupied classroom frame with a person silhouette."""
        # Start with the empty frame
        frame = self._create_default_empty_frame().copy()
        
        # Add a simple person silhouette
        # Head
        cv2.circle(frame, (320, 250), 20, (50, 50, 200), -1)
        
        # Body
        cv2.rectangle(frame, (310, 270), (330, 340), (50, 50, 200), -1)
        
        # Arms
        cv2.rectangle(frame, (290, 280), (310, 290), (50, 50, 200), -1)  # Left arm
        cv2.rectangle(frame, (330, 280), (350, 290), (50, 50, 200), -1)  # Right arm
        
        # Legs
        cv2.rectangle(frame, (310, 340), (320, 380), (50, 50, 200), -1)  # Left leg
        cv2.rectangle(frame, (320, 340), (330, 380), (50, 50, 200), -1)  # Right leg
        
        # Update text
        cv2.putText(frame, "OCCUPIED CLASSROOM", (160, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                    1, (255, 255, 255), 2)
        
        return frame
    
    def run(self):
        """Main camera simulation loop that runs in a separate thread."""
        self.running = True
        logger.info("Starting camera simulation...")
        
        while self.running:
            # Update the frame based on the simulation mode
            if self.mode == 0:  # Random
                if random.random() < 0.5:
                    self.frame = self._create_default_empty_frame()
                else:
                    self.frame = self._create_default_occupied_frame()
            elif self.mode == 1:  # Always empty
                self.frame = self._create_default_empty_frame()
            elif self.mode == 2:  # Always occupied
                self.frame = self._create_default_occupied_frame()
            elif self.mode == 3:  # Alternating
                self.frame_count += 1
                if (self.frame_count // self.alternating_period) % 2 == 0:
                    self.frame = self._create_default_empty_frame()
                else:
                    self.frame = self._create_default_occupied_frame()
            
            # Add timestamp
            timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
            cv2.putText(self.frame, timestamp, (10, 470), cv2.FONT_HERSHEY_SIMPLEX, 
                        0.5, (255, 255, 255), 1)
            
            # Sleep for the update interval
            time.sleep(self.interval)
    
    def get_frame(self):
        """Get the current camera frame."""
        return self.frame.copy()
    
    def set_simulation_mode(self, mode):
        """
        Set the simulation mode.
        
        Args:
            mode: 0 for random, 1 for always empty, 2 for always occupied, 3 for alternating
        """
        self.mode = mode
        logger.info(f"Camera simulation mode set to {mode}")
    
    def stop(self):
        """Stop the camera simulation thread."""
        self.running = False

class PIRSensorSimulation(threading.Thread):
    """
    Simulates a PIR motion sensor for redundancy in occupancy detection.
    """
    
    def __init__(self, check_interval=1.0):
        """
        Initialize the PIR sensor simulation.
        
        Args:
            check_interval: How often to check for motion in seconds
        """
        threading.Thread.__init__(self)
        self.daemon = True
        self.check_interval = check_interval
        self.running = False
        self.motion_detected = False
        self.mode = 0  # 0 = random, 1 = always detect, 2 = never detect
    
    def run(self):
        """Main PIR simulation loop that runs in a separate thread."""
        self.running = True
        logger.info("Starting PIR motion sensor simulation...")
        
        while self.running:
            # Update motion detection based on the simulation mode
            if self.mode == 0:  # Random
                self.motion_detected = random.random() < 0.7  # 70% chance of motion
            elif self.mode == 1:  # Always detect
                self.motion_detected = True
            elif self.mode == 2:  # Never detect
                self.motion_detected = False
            
            logger.debug(f"PIR motion: {'Detected' if self.motion_detected else 'None'}")
            
            # Sleep for the check interval
            time.sleep(self.check_interval)
    
    def is_motion_detected(self):
        """Return whether motion is currently detected."""
        return self.motion_detected
    
    def set_simulation_mode(self, mode):
        """
        Set the simulation mode.
        
        Args:
            mode: 0 for random, 1 for always detect, 2 for never detect
        """
        self.mode = mode
        logger.info(f"PIR simulation mode set to {mode}")
    
    def stop(self):
        """Stop the PIR sensor simulation thread."""
        self.running = False