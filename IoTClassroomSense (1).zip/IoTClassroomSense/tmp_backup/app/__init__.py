import os
import logging
from flask import Flask
from app.extensions import db, login_manager

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def create_app():
    """Create and configure Flask application."""
    app = Flask(__name__, template_folder='../templates', static_folder='../static')
    
    # Configure app
    app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev_key_for_classroom_automation")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    
    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    
    # Register blueprints and routes
    with app.app_context():
        # Register routes
        from app.routes import register_routes
        register_routes(app)
        
        # Register error handlers
        from app.error_handlers import register_error_handlers
        register_error_handlers(app)
        
        # Register filters
        from app.filters import register_filters
        register_filters(app)
        
        # Import models (after registering everything)
        from app.models import User, SystemState, Log, Sensor
        
        # Create database tables
        db.create_all()
        
        # Check if admin user exists, create one if not
        if not User.query.filter_by(username="admin").first():
            admin = User(
                username="admin",
                email="admin@example.com",
                is_admin=True
            )
            admin.set_password("admin123")
            db.session.add(admin)
            
            # Create initial system state
            if not SystemState.query.first():
                state = SystemState()
                db.session.add(state)
                
            db.session.commit()
            logger.info("Created initial admin user and system state")
        
    return app