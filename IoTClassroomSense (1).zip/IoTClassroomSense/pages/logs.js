import { useState, useEffect } from 'react';
import Head from 'next/head';
import { 
  Container, 
  Box, 
  Typography, 
  Paper, 
  Button,
  IconButton,
  InputBase,
  CircularProgress,
  Alert,
  Pagination,
  Chip,
  Grid,
  Card,
  CardContent,
  FormControl,
  InputLabel,
  MenuItem,
  Select
} from '@mui/material';
import { 
  Search, 
  Refresh, 
  ArrowBack,
  FilterList,
  Event,
  Alarm,
  Info,
  Warning,
  Error as ErrorIcon
} from '@mui/icons-material';
import { DataGrid } from '@mui/x-data-grid';
import { ThemeProvider } from '@mui/material/styles';
import theme from '../styles/theme';
import axios from 'axios';

export default function LogsPage() {
  // State for logs data
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(25);
  const [totalLogs, setTotalLogs] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterEvent, setFilterEvent] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  
  // Get unique event types
  const eventTypes = [...new Set(logs.map(log => log.event))];
  
  // Fetch logs data
  const fetchLogs = async () => {
    setRefreshing(true);
    try {
      const offset = page * pageSize;
      const response = await axios.get(`/api/logs?limit=${pageSize}&offset=${offset}`);
      setLogs(response.data.logs);
      setTotalLogs(response.data.pagination.total);
      setLoading(false);
      setRefreshing(false);
    } catch (err) {
      console.error('Error fetching logs:', err);
      setError('Failed to load system logs. Please check your connection.');
      setLoading(false);
      setRefreshing(false);
    }
  };
  
  // Initialize and fetch logs
  useEffect(() => {
    fetchLogs();
  }, [page, pageSize]);
  
  // Handle page change
  const handlePageChange = (newPage) => {
    setPage(newPage);
  };
  
  // Handle search
  const handleSearch = (e) => {
    e.preventDefault();
    fetchLogs();
  };
  
  // Handle filter change
  const handleFilterChange = (event) => {
    setFilterEvent(event.target.value);
  };
  
  // Filter logs by search term and event type
  const filteredLogs = logs.filter(log => 
    (searchTerm === '' || log.details.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (filterEvent === '' || log.event === filterEvent)
  );
  
  // Loading state
  if (loading) {
    return (
      <ThemeProvider theme={theme}>
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
          <CircularProgress size={60} />
          <Typography variant="h6" sx={{ ml: 2 }}>Loading logs...</Typography>
        </Box>
      </ThemeProvider>
    );
  }
  
  // Error state
  if (error) {
    return (
      <ThemeProvider theme={theme}>
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', flexDirection: 'column' }}>
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
          <Button variant="contained" onClick={() => { setLoading(true); fetchLogs(); }}>
            Retry
          </Button>
        </Box>
      </ThemeProvider>
    );
  }
  
  // Prepare columns for DataGrid
  const columns = [
    { 
      field: 'timestamp', 
      headerName: 'Time', 
      width: 200,
      valueGetter: (params) => new Date(params.value * 1000).toLocaleString(),
      renderCell: (params) => (
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Alarm sx={{ mr: 1, color: 'text.secondary', fontSize: 16 }} />
          {new Date(params.value * 1000).toLocaleString()}
        </Box>
      )
    },
    { 
      field: 'event', 
      headerName: 'Event', 
      width: 200,
      renderCell: (params) => (
        <Chip 
          label={params.value} 
          size="small"
          icon={getEventIcon(params.value)}
          sx={{ 
            backgroundColor: getEventColor(params.value),
            color: '#fff'
          }}
        />
      )
    },
    { 
      field: 'details', 
      headerName: 'Details', 
      flex: 1,
      renderCell: (params) => (
        <Typography variant="body2">{params.value}</Typography>
      )
    },
  ];
  
  return (
    <ThemeProvider theme={theme}>
      <Head>
        <title>System Logs | IoT Classroom Automation</title>
        <meta name="description" content="System logs for smart classroom automation" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Box sx={{ mb: 4 }}>
          <Button 
            variant="outlined" 
            startIcon={<ArrowBack />} 
            href="/"
            sx={{ mb: 2 }}
          >
            Back to Dashboard
          </Button>
          <Typography variant="h4" component="h1" gutterBottom>
            System Logs
          </Typography>
          <Typography variant="body1" color="text.secondary" paragraph>
            View and analyze system events and actions
          </Typography>
        </Box>
        
        {/* Filters and Search */}
        <Paper sx={{ p: 2, mb: 3, display: 'flex', alignItems: 'center', flexWrap: 'wrap' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mr: 2, flex: '1 1 300px', mb: { xs: 2, md: 0 } }}>
            <IconButton sx={{ p: '10px' }} aria-label="search">
              <Search />
            </IconButton>
            <InputBase
              sx={{ ml: 1, flex: 1 }}
              placeholder="Search log details"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch(e)}
            />
          </Box>
          
          <FormControl sx={{ minWidth: 120, mr: 2, flex: '0 0 auto' }}>
            <InputLabel id="event-filter-label">Event Type</InputLabel>
            <Select
              labelId="event-filter-label"
              id="event-filter"
              value={filterEvent}
              label="Event Type"
              onChange={handleFilterChange}
              size="small"
            >
              <MenuItem value="">
                <em>All Events</em>
              </MenuItem>
              {eventTypes.map(type => (
                <MenuItem key={type} value={type}>
                  {type}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          
          <Button 
            variant="contained" 
            color="primary" 
            startIcon={<Refresh />}
            onClick={fetchLogs}
            disabled={refreshing}
            sx={{ flex: '0 0 auto' }}
          >
            {refreshing ? 'Refreshing...' : 'Refresh'}
          </Button>
        </Paper>
        
        {/* Log Statistics */}
        <Grid container spacing={3} sx={{ mb: 3 }}>
          <Grid item xs={12} md={3}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography variant="h6" gutterBottom>Total Logs</Typography>
                <Typography variant="h3">{totalLogs}</Typography>
              </CardContent>
            </Card>
          </Grid>
          
          <Grid item xs={12} md={3}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography variant="h6" gutterBottom>Occupancy Events</Typography>
                <Typography variant="h3">
                  {logs.filter(log => log.event.includes('occupancy')).length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          
          <Grid item xs={12} md={3}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography variant="h6" gutterBottom>Appliance Events</Typography>
                <Typography variant="h3">
                  {logs.filter(log => log.event.includes('appliance')).length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          
          <Grid item xs={12} md={3}>
            <Card>
              <CardContent sx={{ textAlign: 'center' }}>
                <Typography variant="h6" gutterBottom>Manual Overrides</Typography>
                <Typography variant="h3">
                  {logs.filter(log => log.event === 'manual_override').length}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
        
        {/* Logs Table */}
        <Paper sx={{ height: 600, width: '100%' }}>
          <DataGrid
            rows={filteredLogs}
            columns={columns}
            pageSize={pageSize}
            rowsPerPageOptions={[25, 50, 100]}
            onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
            page={page}
            onPageChange={(newPage) => handlePageChange(newPage)}
            rowCount={totalLogs}
            paginationMode="server"
            disableSelectionOnClick
            loading={refreshing}
            sx={{
              '& .MuiDataGrid-cell:focus': {
                outline: 'none',
              },
              '& .MuiDataGrid-columnHeader:focus': {
                outline: 'none',
              }
            }}
          />
        </Paper>
      </Container>
    </ThemeProvider>
  );
}

// Helper function to get event color
function getEventColor(event) {
  switch (event) {
    case 'occupancy_detected':
      return '#66BB6A'; // Green
    case 'occupancy_lost':
      return '#FF5252'; // Red
    case 'appliance_on':
      return '#42A5F5'; // Blue
    case 'appliance_off':
      return '#78909C'; // Gray
    case 'manual_override':
      return '#FFB74D'; // Orange
    case 'simulation':
      return '#BA68C8'; // Purple
    case 'system_startup':
      return '#26A69A'; // Teal
    case 'error':
      return '#E53935'; // Dark Red
    default:
      return '#90A4AE'; // Light Gray
  }
}

// Helper function to get event icon
function getEventIcon(event) {
  switch (event) {
    case 'occupancy_detected':
    case 'occupancy_lost':
      return <Event />;
    case 'appliance_on':
    case 'appliance_off':
      return <Info />;
    case 'manual_override':
      return <Warning />;
    case 'error':
      return <ErrorIcon />;
    default:
      return <Info />;
  }
}