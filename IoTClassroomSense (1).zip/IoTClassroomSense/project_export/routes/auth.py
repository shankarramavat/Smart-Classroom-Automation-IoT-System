from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from app import db
from models import User, Log
import datetime

auth = Blueprint('auth', __name__)

@auth.route('/login', methods=['GET', 'POST'])
def login():
    """Login page."""
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False
        
        user = User.query.filter_by(username=username).first()
        
        # Check if user exists and password is correct
        if not user or not user.check_password(password):
            flash('Please check your login details and try again.', 'danger')
            return redirect(url_for('auth.login'))
        
        # Update last login timestamp
        user.last_login = datetime.datetime.utcnow()
        
        # Log login event
        log = Log(
            event_type='user_login',
            device='web_interface',
            details=f'User {username} logged in',
            user_id=user.id
        )
        
        db.session.add(log)
        db.session.commit()
        
        # Log in user
        login_user(user, remember=remember)
        
        # Redirect to the appropriate dashboard
        if user.is_admin:
            return redirect(url_for('admin.admin_dashboard'))
        return redirect(url_for('main.dashboard'))
    
    return render_template('login.html', title='Login')

@auth.route('/signup', methods=['GET', 'POST'])
def signup():
    """Sign up page."""
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Check if passwords match
        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return redirect(url_for('auth.signup'))
        
        # Check if username exists
        user = User.query.filter_by(username=username).first()
        if user:
            flash('Username already exists.', 'danger')
            return redirect(url_for('auth.signup'))
        
        # Check if email exists
        user = User.query.filter_by(email=email).first()
        if user:
            flash('Email already exists.', 'danger')
            return redirect(url_for('auth.signup'))
        
        # Create new user
        new_user = User(username=username, email=email)
        new_user.set_password(password)
        
        db.session.add(new_user)
        db.session.commit()
        
        # Log signup event
        log = Log(
            event_type='user_signup',
            device='web_interface',
            details=f'New user {username} registered',
            user_id=new_user.id
        )
        
        db.session.add(log)
        db.session.commit()
        
        flash('Account created successfully! You can now log in.', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('signup.html', title='Sign Up')

@auth.route('/logout')
@login_required
def logout():
    """Logout route."""
    # Log logout event
    log = Log(
        event_type='user_logout',
        device='web_interface',
        details=f'User {current_user.username} logged out',
        user_id=current_user.id
    )
    
    db.session.add(log)
    db.session.commit()
    
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))

@auth.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    """User profile page."""
    if request.method == 'POST':
        email = request.form.get('email')
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        # Check if email changed
        if email != current_user.email:
            # Check if email exists
            user = User.query.filter_by(email=email).first()
            if user and user.id != current_user.id:
                flash('Email already exists.', 'danger')
                return redirect(url_for('auth.profile'))
            
            current_user.email = email
            flash('Email updated successfully.', 'success')
        
        # Check if password change requested
        if current_password and new_password and confirm_password:
            # Check if current password is correct
            if not current_user.check_password(current_password):
                flash('Current password is incorrect.', 'danger')
                return redirect(url_for('auth.profile'))
            
            # Check if new passwords match
            if new_password != confirm_password:
                flash('New passwords do not match.', 'danger')
                return redirect(url_for('auth.profile'))
            
            # Update password
            current_user.set_password(new_password)
            flash('Password updated successfully.', 'success')
        
        db.session.commit()
        
        # Log profile update event
        log = Log(
            event_type='profile_update',
            device='web_interface',
            details=f'User {current_user.username} updated profile',
            user_id=current_user.id
        )
        
        db.session.add(log)
        db.session.commit()
        
        return redirect(url_for('auth.profile'))
    
    return render_template('auth/profile.html', title='User Profile')