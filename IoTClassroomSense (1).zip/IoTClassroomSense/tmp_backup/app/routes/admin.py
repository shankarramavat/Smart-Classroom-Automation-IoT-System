from functools import wraps
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app.extensions import db
from app.models import User, SystemState, Log, Sensor

admin = Blueprint('admin', __name__, url_prefix='/admin')

# Admin required decorator
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('You do not have permission to access this page', 'danger')
            return redirect(url_for('main.dashboard'))
        return f(*args, **kwargs)
    return decorated_function

@admin.route('/')
@login_required
@admin_required
def admin_dashboard():
    """Admin dashboard page."""
    # Get all users
    all_users = User.query.all()
    
    # Get all sensors
    sensors = Sensor.query.all()
    
    return render_template(
        'admin.html',
        user=current_user,
        all_users=all_users,
        sensors=sensors
    )

@admin.route('/users')
@login_required
@admin_required
def manage_users():
    """User management page."""
    users = User.query.all()
    return render_template('admin/users.html', user=current_user, users=users)

@admin.route('/users/create', methods=['GET', 'POST'])
@login_required
@admin_required
def create_user():
    """Create new user page."""
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        is_admin = 'is_admin' in request.form
        
        # Validate inputs
        if not username or not email or not password:
            flash('All fields are required', 'danger')
            return redirect(url_for('admin.create_user'))
            
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return redirect(url_for('admin.create_user'))
            
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'danger')
            return redirect(url_for('admin.create_user'))
            
        # Create new user
        user = User(username=username, email=email, is_admin=is_admin)
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        # Log the user creation
        log = Log(
            event_type="user_created",
            details=f"Admin {current_user.username} created new user {username}",
            user_id=current_user.id
        )
        db.session.add(log)
        db.session.commit()
        
        flash(f'User {username} created successfully', 'success')
        return redirect(url_for('admin.manage_users'))
    
    return render_template('admin/create_user.html', user=current_user)

@admin.route('/users/<int:id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_user(id):
    """Edit user page."""
    user_to_edit = User.query.get_or_404(id)
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        is_admin = 'is_admin' in request.form
        
        # Validate inputs
        if not username or not email:
            flash('Username and email are required', 'danger')
            return redirect(url_for('admin.edit_user', id=id))
            
        # Check if username exists and is not the current user
        existing_user = User.query.filter_by(username=username).first()
        if existing_user and existing_user.id != id:
            flash('Username already exists', 'danger')
            return redirect(url_for('admin.edit_user', id=id))
            
        # Check if email exists and is not the current user
        existing_email = User.query.filter_by(email=email).first()
        if existing_email and existing_email.id != id:
            flash('Email already exists', 'danger')
            return redirect(url_for('admin.edit_user', id=id))
        
        # Update user details
        user_to_edit.username = username
        user_to_edit.email = email
        user_to_edit.is_admin = is_admin
        
        # Update password if provided
        if password:
            user_to_edit.set_password(password)
            
        db.session.commit()
        
        # Log the user update
        log = Log(
            event_type="user_updated",
            details=f"Admin {current_user.username} updated user {username}",
            user_id=current_user.id
        )
        db.session.add(log)
        db.session.commit()
        
        flash(f'User {username} updated successfully', 'success')
        return redirect(url_for('admin.manage_users'))
    
    return render_template('admin/edit_user.html', user=current_user, user_to_edit=user_to_edit)

@admin.route('/users/<int:id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_user(id):
    """Delete user."""
    user_to_delete = User.query.get_or_404(id)
    
    # Prevent self-deletion
    if user_to_delete.id == current_user.id:
        flash('You cannot delete your own account', 'danger')
        return redirect(url_for('admin.manage_users'))
    
    username = user_to_delete.username
    
    db.session.delete(user_to_delete)
    db.session.commit()
    
    # Log the user deletion
    log = Log(
        event_type="user_deleted",
        details=f"Admin {current_user.username} deleted user {username}",
        user_id=current_user.id
    )
    db.session.add(log)
    db.session.commit()
    
    flash(f'User {username} deleted successfully', 'success')
    return redirect(url_for('admin.manage_users'))

@admin.route('/sensors')
@login_required
@admin_required
def manage_sensors():
    """Sensor management page."""
    sensors = Sensor.query.all()
    return render_template('admin/sensors.html', user=current_user, sensors=sensors)

@admin.route('/sensors/create', methods=['GET', 'POST'])
@login_required
@admin_required
def create_sensor():
    """Create new sensor page."""
    if request.method == 'POST':
        sensor_id = request.form.get('sensor_id')
        sensor_type = request.form.get('sensor_type')
        location = request.form.get('location')
        ip_address = request.form.get('ip_address')
        status = request.form.get('status')
        
        # Validate inputs
        if not sensor_id or not sensor_type or not location:
            flash('Sensor ID, type, and location are required', 'danger')
            return redirect(url_for('admin.create_sensor'))
            
        # Check if sensor ID already exists
        if Sensor.query.filter_by(sensor_id=sensor_id).first():
            flash('Sensor ID already exists', 'danger')
            return redirect(url_for('admin.create_sensor'))
            
        # Create new sensor
        sensor = Sensor(
            sensor_id=sensor_id,
            sensor_type=sensor_type,
            location=location,
            ip_address=ip_address,
            status=status
        )
        
        db.session.add(sensor)
        db.session.commit()
        
        # Log the sensor creation
        log = Log(
            event_type="sensor_created",
            device=sensor_id,
            details=f"Admin {current_user.username} created new sensor {sensor_id}",
            user_id=current_user.id
        )
        db.session.add(log)
        db.session.commit()
        
        flash(f'Sensor {sensor_id} created successfully', 'success')
        return redirect(url_for('admin.manage_sensors'))
    
    return render_template('admin/create_sensor.html', user=current_user)

@admin.route('/sensors/<int:id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_sensor(id):
    """Edit sensor page."""
    sensor = Sensor.query.get_or_404(id)
    
    if request.method == 'POST':
        sensor_id = request.form.get('sensor_id')
        sensor_type = request.form.get('sensor_type')
        location = request.form.get('location')
        ip_address = request.form.get('ip_address')
        status = request.form.get('status')
        
        # Validate inputs
        if not sensor_id or not sensor_type or not location:
            flash('Sensor ID, type, and location are required', 'danger')
            return redirect(url_for('admin.edit_sensor', id=id))
            
        # Check if sensor ID exists and is not the current sensor
        existing_sensor = Sensor.query.filter_by(sensor_id=sensor_id).first()
        if existing_sensor and existing_sensor.id != id:
            flash('Sensor ID already exists', 'danger')
            return redirect(url_for('admin.edit_sensor', id=id))
        
        # Update sensor details
        sensor.sensor_id = sensor_id
        sensor.sensor_type = sensor_type
        sensor.location = location
        sensor.ip_address = ip_address
        sensor.status = status
            
        db.session.commit()
        
        # Log the sensor update
        log = Log(
            event_type="sensor_updated",
            device=sensor_id,
            details=f"Admin {current_user.username} updated sensor {sensor_id}",
            user_id=current_user.id
        )
        db.session.add(log)
        db.session.commit()
        
        flash(f'Sensor {sensor_id} updated successfully', 'success')
        return redirect(url_for('admin.manage_sensors'))
    
    return render_template('admin/edit_sensor.html', user=current_user, sensor=sensor)

@admin.route('/sensors/<int:id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_sensor(id):
    """Delete sensor."""
    sensor = Sensor.query.get_or_404(id)
    
    sensor_id = sensor.sensor_id
    
    db.session.delete(sensor)
    db.session.commit()
    
    # Log the sensor deletion
    log = Log(
        event_type="sensor_deleted",
        device=sensor_id,
        details=f"Admin {current_user.username} deleted sensor {sensor_id}",
        user_id=current_user.id
    )
    db.session.add(log)
    db.session.commit()
    
    flash(f'Sensor {sensor_id} deleted successfully', 'success')
    return redirect(url_for('admin.manage_sensors'))

def register_admin_routes(app):
    """Register admin routes with the Flask app."""
    app.register_blueprint(admin)