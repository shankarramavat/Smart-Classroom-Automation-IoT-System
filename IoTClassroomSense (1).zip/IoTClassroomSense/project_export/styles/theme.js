import { createTheme } from '@mui/material/styles';

// Create a custom theme with Indian-inspired color palette
const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#FF9933', // Saffron color from Indian flag
      light: '#FFB266',
      dark: '#CC7A29',
      contrastText: '#FFFFFF',
    },
    secondary: {
      main: '#138808', // Green color from Indian flag
      light: '#26A69A',
      dark: '#0F6A06',
      contrastText: '#FFFFFF',
    },
    tertiary: {
      main: '#0000CD', // Navy Blue from Ashoka Chakra
      light: '#3366FF',
      dark: '#000099',
      contrastText: '#FFFFFF',
    },
    background: {
      default: '#121212',
      paper: '#1E1E1E',
    },
    error: {
      main: '#FF5252',
    },
    warning: {
      main: '#FFB74D',
    },
    info: {
      main: '#64B5F6',
    },
    success: {
      main: '#66BB6A',
    },
  },
  typography: {
    fontFamily: '"Poppins", "Roboto", "Helvetica", "Arial", sans-serif',
    h1: {
      fontWeight: 600,
    },
    h2: {
      fontWeight: 600,
    },
    h3: {
      fontWeight: 600,
    },
    h4: {
      fontWeight: 600,
    },
    h5: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: '0 4px 20px 0 rgba(0,0,0,0.2)',
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          textTransform: 'none',
          fontWeight: 600,
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 8,
        },
      },
    },
  },
});

export default theme;