import React from 'react';
import { 
  Card, 
  Typography, 
  Box, 
  IconButton
} from '@mui/material';
import { 
  PowerSettingsNew,
  AutoMode
} from '@mui/icons-material';

const IoTDeviceCard = ({ 
  title, 
  icon: Icon, 
  status, 
  override, 
  overrideState, 
  color,
  hoverColor,
  onOverride 
}) => {
  return (
    <Card 
      sx={{ 
        p: 2, 
        display: 'flex', 
        flexDirection: 'column', 
        alignItems: 'center',
        bgcolor: status ? `rgba(${hoverColor}, 0.1)` : 'background.paper',
        borderRadius: '8px',
        transition: 'transform 0.2s ease, box-shadow 0.2s ease',
        '&:hover': {
          transform: 'translateY(-4px)',
          boxShadow: 4
        }
      }}
    >
      <Icon 
        sx={{ 
          fontSize: 40, 
          color: status ? color : 'text.disabled',
          mb: 1
        }} 
      />
      <Typography variant="h6">{title}</Typography>
      <Typography 
        variant="body2" 
        color={override ? 'warning.main' : 'text.secondary'}
        sx={{ mb: 1 }}
      >
        {override ? 'Manual Override' : 'Auto Control'}
      </Typography>
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 1 }}>
        <IconButton
          size="small"
          color={overrideState === true ? 'primary' : 'default'}
          onClick={() => onOverride(true)}
          sx={{ 
            mx: 0.5, 
            transition: 'all 0.2s',
            '&:hover': {
              backgroundColor: 'rgba(255, 153, 51, 0.1)'
            }
          }}
          aria-label={`Turn ${title} on`}
        >
          <PowerSettingsNew />
        </IconButton>
        <IconButton
          size="small"
          color={overrideState === false ? 'error' : 'default'}
          onClick={() => onOverride(false)}
          sx={{ 
            mx: 0.5, 
            transition: 'all 0.2s',
            '&:hover': {
              backgroundColor: 'rgba(255, 82, 82, 0.1)'
            }
          }}
          aria-label={`Turn ${title} off`}
        >
          <PowerSettingsNew />
        </IconButton>
        <IconButton
          size="small"
          color={overrideState === null ? 'success' : 'default'}
          onClick={() => onOverride(null)}
          sx={{ 
            mx: 0.5, 
            transition: 'all 0.2s',
            '&:hover': {
              backgroundColor: 'rgba(102, 187, 106, 0.1)'
            }
          }}
          aria-label={`Set ${title} to auto mode`}
        >
          <AutoMode />
        </IconButton>
      </Box>
    </Card>
  );
};

export default IoTDeviceCard;