# Vercel Deployment Guide for Classroom Automation System

## Problem Identified
Your Vercel deployment is failing because this project is a hybrid application with both Next.js frontend and Flask backend. Vercel can only host the Next.js portion.

## Solution Steps

### 1. Prepare Your Frontend for Vercel Deployment

Create a separate GitHub repository for just the frontend files:

- Copy these folders and files to the new repository:
  - `/components`
  - `/pages`
  - `/styles`
  - `/next.config.js`

### 2. Create a Proper package.json

In your new repository, create a proper package.json file:

```json
{
  "name": "classroom-automation-frontend",
  "version": "1.0.0",
  "main": "index.js",
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  },
  "keywords": ["iot", "classroom-automation", "computer-vision"],
  "author": "",
  "license": "ISC",
  "description": "Smart Classroom Automation System with IoT and Computer Vision",
  "engines": {
    "node": ">=18.17.0"
  },
  "dependencies": {
    "@emotion/react": "^11.11.0",
    "@emotion/styled": "^11.11.0",
    "@mui/icons-material": "^5.14.0",
    "@mui/material": "^5.14.0",
    "@mui/x-data-grid": "^6.10.0",
    "axios": "^1.4.0",
    "chart.js": "^4.3.0",
    "next": "^13.4.10",
    "react": "^18.2.0",
    "react-chartjs-2": "^5.2.0",
    "react-dom": "^18.2.0",
    "recharts": "^2.7.2"
  }
}
```

### 3. Update next.config.js

Make sure your next.config.js has this content (we've already updated it):

```js
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  async rewrites() {
    return [
      {
        // Rewrite API requests to Flask backend
        source: '/api/:path*',
        destination: process.env.BACKEND_URL || 'http://localhost:5000/api/:path*',
      },
    ];
  },
  // Add Indian Rupee currency symbol support
  i18n: {
    locales: ['en-IN'],
    defaultLocale: 'en-IN',
  },
};

module.exports = nextConfig;
```

### 4. Deploy Backend Separately

Your Flask backend needs to be deployed to a different platform:
- Good options include Heroku, Render, Railway, or DigitalOcean
- Make sure the database connection works properly
- Update environment variables on both frontend and backend

### 5. Set Up Environment Variables in Vercel

In your Vercel project settings, add:

```
BACKEND_URL=https://your-flask-backend-url.com/api
```

Replace with your actual backend URL once it's deployed.

### 6. Deploy to Vercel

1. Connect your GitHub repository with the frontend code
2. Choose "Next.js" as the Framework Preset
3. Set the Root Directory to where your `next.config.js` is located
4. Add the environment variables
5. Deploy!

## Common Deployment Errors

1. **"Module not found" errors**: Check that your dependency versions are compatible and properly installed.

2. **API connection issues**: Make sure your `BACKEND_URL` environment variable is set correctly and points to a running Flask backend.

3. **Next.js build failures**: Ensure your code doesn't use React features that are incompatible with Next.js, like browser-only APIs without proper checks.

4. **Database connection failures**: Your Flask backend needs proper database connection strings. Make sure environment variables are configured correctly.

## Testing Your Deployment

After deployment, check these common issues:
- Can you log in and sign up?
- Are appliance controls working?
- Is the data visualization loading correctly?
- Check browser console for any API errors

If you run into problems, check both the Vercel logs and your backend logs.