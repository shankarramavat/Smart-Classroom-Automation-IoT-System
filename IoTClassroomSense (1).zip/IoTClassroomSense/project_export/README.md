# Smart Classroom Automation System

An intelligent IoT classroom automation platform that transforms educational spaces through advanced technology. The system combines cutting-edge sensor technologies, computer vision, and interactive interfaces to optimize energy management, occupancy tracking, and environmental control.

## Features

- **Occupancy Detection**: Uses computer vision with OpenCV to detect people in a classroom
- **Automatic Appliance Control**: Turns appliances on/off based on occupancy with customizable delays
- **PIR Motion Sensor Redundancy**: Additional detection method for reliability
- **Manual Override Controls**: Override automatic controls when needed
- **Energy Savings Tracking**: Monitors and calculates energy savings in kWh and INR (₹)
- **Analytics Dashboard**: Visualizes usage patterns, occupancy rates, and energy savings
- **User Authentication**: Secure login/signup with admin privileges for system configuration
- **Responsive Web Interface**: Access the system from any device
- **Temperature & Humidity Monitoring**: Real-time environmental data

## Technology Stack

- **Backend**: Python Flask
- **Frontend**: Next.js, React, Material UI
- **Database**: PostgreSQL with SQLAlchemy ORM
- **Computer Vision**: OpenCV with MobileNet SSD model
- **Sensors**: Temperature, Humidity, PIR Motion (simulated)
- **IoT Control**: Simulated MQTT for smart plugs and GPIO for relays

## Installation

### Prerequisites
- Python 3.8+
- Node.js 16+
- PostgreSQL database

### Setup Instructions

1. Clone the repository
   ```
   git clone https://github.com/yourusername/classroom-automation-system.git
   cd classroom-automation-system
   ```

2. Create and activate a virtual environment
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install Python dependencies
   ```
   pip install -r requirements.txt
   ```

4. Install Node.js dependencies
   ```
   npm install
   ```

5. Create a `.env` file based on `.env.sample` and configure your environment variables
   ```
   cp .env.sample .env
   # Edit .env with your PostgreSQL credentials and other settings
   ```

6. Initialize the database
   ```
   flask db upgrade
   ```

7. Start the Flask server
   ```
   python main.py
   ```

8. In a separate terminal, start the Next.js frontend
   ```
   npm run dev
   ```

9. Access the application at `http://localhost:5000`

## Usage

### Admin Setup
1. Register a new account
2. Access the PostgreSQL database and set the `is_admin` flag to true for your user
   ```sql
   UPDATE users SET is_admin = TRUE WHERE username = 'your_username';
   ```
3. Log in with your account to access admin features

### Classroom Control
- Use the dashboard to monitor classroom status in real-time
- Toggle manual overrides for lights, AC, and fan as needed
- View occupancy status and environmental conditions
- Check energy savings and cost reduction metrics

### Analytics
- View historical data on occupancy patterns
- Analyze energy usage and savings trends
- Export reports for administrative purposes

## Simulation Mode

For testing without physical hardware, the system includes simulation modes:

- **Camera Simulation**: Alternates between empty and occupied classroom images
- **PIR Sensor Simulation**: Generates simulated motion detection events
- **Environmental Sensors**: Provides realistic temperature and humidity readings

To adjust simulation settings, use the admin panel or modify the relevant parameters in the code.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Contact

- Developer: Shankar Ramava
- Email: shankar.ramava15@gmail.com
- Phone: 8806959943

## License

This project is licensed under the MIT License - see the LICENSE file for details.