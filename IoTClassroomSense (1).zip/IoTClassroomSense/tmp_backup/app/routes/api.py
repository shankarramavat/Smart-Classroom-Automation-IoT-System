from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from app.extensions import db
from app.models import SystemState, Log, Sensor

api = Blueprint('api', __name__, url_prefix='/api')

@api.route('/status')
@login_required
def get_status():
    """Get system status."""
    state = SystemState.query.order_by(SystemState.id.desc()).first()
    
    if not state:
        return jsonify({'error': 'System state not found'}), 404
        
    return jsonify({
        'is_occupied': state.is_occupied,
        'lights_on': state.lights_on,
        'ac_on': state.ac_on,
        'fan_on': state.fan_on,
        'temperature': state.temperature,
        'humidity': state.humidity,
        'motion_detected': state.motion_detected,
        'energy_saved': state.energy_saved,
        'cost_saved': state.cost_saved,
        'updated_at': state.updated_at.isoformat()
    })

@api.route('/logs')
@login_required
def get_logs():
    """Get system logs."""
    limit = request.args.get('limit', 10, type=int)
    
    logs = Log.query.order_by(Log.timestamp.desc()).limit(limit).all()
    
    return jsonify([{
        'id': log.id,
        'timestamp': log.timestamp.isoformat(),
        'event_type': log.event_type,
        'device': log.device,
        'details': log.details,
        'user_id': log.user_id
    } for log in logs])

@api.route('/override/<device>', methods=['POST'])
@login_required
def override_control(device):
    """Manual override of device controls."""
    if device not in ['lights', 'ac', 'fan', 'all']:
        return jsonify({'error': 'Invalid device specified'}), 400
        
    state = request.json.get('state')
    if state not in [True, False]:
        return jsonify({'error': 'Invalid state specified'}), 400
    
    system_state = SystemState.query.order_by(SystemState.id.desc()).first()
    
    if device == 'lights' or device == 'all':
        system_state.lights_override = True
        system_state.lights_on = state
        
    if device == 'ac' or device == 'all':
        system_state.ac_override = True
        system_state.ac_on = state
        
    if device == 'fan' or device == 'all':
        system_state.fan_override = True
        system_state.fan_on = state
    
    db.session.commit()
    
    # Log the override
    log = Log(
        event_type="override",
        device=device,
        details=f"{device.capitalize()} {'turned on' if state else 'turned off'} manually by {current_user.username}",
        user_id=current_user.id
    )
    db.session.add(log)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': f"{device.capitalize()} {'turned on' if state else 'turned off'} successfully"
    })

@api.route('/sensors')
@login_required
def get_sensors():
    """Get IoT sensor data."""
    sensors = Sensor.query.all()
    
    return jsonify([{
        'id': sensor.id,
        'sensor_id': sensor.sensor_id,
        'sensor_type': sensor.sensor_type,
        'location': sensor.location,
        'status': sensor.status,
        'last_reading': sensor.last_reading,
        'last_reading_unit': sensor.last_reading_unit,
        'last_updated': sensor.last_updated.isoformat() if sensor.last_updated else None
    } for sensor in sensors])

def register_api_routes(app):
    """Register API routes with the Flask app."""
    app.register_blueprint(api)