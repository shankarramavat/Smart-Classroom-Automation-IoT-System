from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from app import db
from models import SystemState, Log, Sensor
import datetime

main = Blueprint('main', __name__)

@main.route('/')
def index():
    """Home page."""
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return render_template('index.html')

@main.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard."""
    state = SystemState.query.first()
    if not state:
        state = SystemState()
        db.session.add(state)
        db.session.commit()
    
    # Get latest logs
    logs = Log.query.order_by(Log.timestamp.desc()).limit(10).all()
    
    # Get sensors
    sensors = Sensor.query.all()
    
    # Calculate uptime (simulated for demonstration)
    uptime = {
        'days': 3,
        'hours': 12,
        'minutes': 45,
        'seconds': 30
    }
    
    # Calculate energy savings (simulated for demonstration)
    energy_saved = state.energy_saved
    cost_saved = state.cost_saved
    
    # Calculate occupancy statistics (simulated for demonstration)
    occupancy_data = {
        'today': 65,  # percentage of time occupied today
        'week': 58,   # percentage of time occupied this week
        'month': 62   # percentage of time occupied this month
    }
    
    # Calculate status of devices
    devices_status = {
        'lights': state.lights_on,
        'ac': state.ac_on,
        'fan': state.fan_on,
        'temperature': state.temperature,
        'humidity': state.humidity,
        'motion': state.motion_detected,
        'occupied': state.is_occupied
    }
    
    return render_template(
        'dashboard.html', 
        title='Dashboard',
        user=current_user,
        system_state=state,
        logs=logs,
        sensors=sensors,
        uptime=uptime,
        energy_saved=energy_saved,
        cost_saved=cost_saved,
        occupancy_data=occupancy_data,
        devices_status=devices_status
    )

@main.route('/analytics')
@login_required
def analytics():
    """Analytics page."""
    # Get current date in IST (Indian Standard Time)
    current_date = datetime.datetime.now().strftime('%Y-%m-%d')
    
    # Sample data for analytics (in a real app, this would come from the database)
    daily_energy_data = [
        {"date": current_date, "lights": 1.2, "ac": 5.8, "fan": 0.9},
        {"date": (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y-%m-%d'), 
         "lights": 1.5, "ac": 6.2, "fan": 1.1},
        {"date": (datetime.datetime.now() - datetime.timedelta(days=2)).strftime('%Y-%m-%d'), 
         "lights": 1.3, "ac": 5.5, "fan": 0.8},
        {"date": (datetime.datetime.now() - datetime.timedelta(days=3)).strftime('%Y-%m-%d'), 
         "lights": 1.4, "ac": 6.0, "fan": 1.0},
        {"date": (datetime.datetime.now() - datetime.timedelta(days=4)).strftime('%Y-%m-%d'), 
         "lights": 1.1, "ac": 5.3, "fan": 0.7},
        {"date": (datetime.datetime.now() - datetime.timedelta(days=5)).strftime('%Y-%m-%d'), 
         "lights": 0.9, "ac": 4.8, "fan": 0.6},
        {"date": (datetime.datetime.now() - datetime.timedelta(days=6)).strftime('%Y-%m-%d'), 
         "lights": 0.7, "ac": 3.9, "fan": 0.5}
    ]
    
    hourly_occupancy_data = [
        {"hour": "08:00", "occupancy": 10},
        {"hour": "09:00", "occupancy": 65},
        {"hour": "10:00", "occupancy": 85},
        {"hour": "11:00", "occupancy": 90},
        {"hour": "12:00", "occupancy": 70},
        {"hour": "13:00", "occupancy": 30},
        {"hour": "14:00", "occupancy": 75},
        {"hour": "15:00", "occupancy": 85},
        {"hour": "16:00", "occupancy": 80},
        {"hour": "17:00", "occupancy": 65},
        {"hour": "18:00", "occupancy": 45},
        {"hour": "19:00", "occupancy": 15}
    ]
    
    return render_template(
        'analytics.html', 
        title='Analytics',
        user=current_user,
        daily_energy_data=daily_energy_data,
        hourly_occupancy_data=hourly_occupancy_data
    )

@main.route('/logs')
@login_required
def logs():
    """Logs page."""
    # Get logs with pagination
    page = request.args.get('page', 1, type=int)
    logs = Log.query.order_by(Log.timestamp.desc()).paginate(page=page, per_page=20)
    return render_template('logs.html', title='System Logs', user=current_user, logs=logs)