import os
import logging
from flask import Flask

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Import the Flask application factory function
from app import create_app

# Create the Flask application instance for Gunicorn
app = create_app()

# Only run this if executed directly (not through Gunicorn)
if __name__ == '__main__':
    # Run the application
    app.run(host='0.0.0.0', port=5000, debug=True)