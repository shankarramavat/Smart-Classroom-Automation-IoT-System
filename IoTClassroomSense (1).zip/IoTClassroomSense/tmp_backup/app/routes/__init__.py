from flask import Flask

def register_routes(app: Flask):
    """Register all application routes with the Flask app."""
    from app.routes.main import register_main_routes
    from app.routes.auth import register_auth_routes
    from app.routes.api import register_api_routes
    from app.routes.admin import register_admin_routes
    
    # Register the blueprints
    register_main_routes(app)
    register_auth_routes(app)
    register_api_routes(app)
    register_admin_routes(app)