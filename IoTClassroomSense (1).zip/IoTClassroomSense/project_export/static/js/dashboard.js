// Dashboard JavaScript for Classroom Automation System

document.addEventListener('DOMContentLoaded', function() {
    // Initialize system status updates
    initSystemStatus();
    
    // Initialize control buttons
    initControlButtons();
    
    // Initialize charts if they exist on the page
    if (document.getElementById('energyChart')) {
        initEnergyChart();
    }
    
    if (document.getElementById('occupancyChart')) {
        initOccupancyChart();
    }
    
    // Initialize sensor gauges
    initSensorGauges();
});

// System Status Updates
function initSystemStatus() {
    // Update system status every 5 seconds
    updateSystemStatus();
    setInterval(updateSystemStatus, 5000);
}

function updateSystemStatus() {
    fetch('/api/status')
        .then(response => response.json())
        .then(data => {
            // Update status indicators
            updateStatusIndicator('occupancy-status', data.occupancy);
            updateStatusIndicator('lights-status', data.lights);
            updateStatusIndicator('ac-status', data.ac);
            updateStatusIndicator('fan-status', data.fan);
            
            // Update temperature and humidity if elements exist
            if (document.getElementById('temperature-value')) {
                document.getElementById('temperature-value').textContent = data.temperature.toFixed(1) + '°C';
                updateTempClass('temperature-value', data.temperature);
            }
            
            if (document.getElementById('humidity-value')) {
                document.getElementById('humidity-value').textContent = data.humidity.toFixed(0) + '%';
            }
            
            // Update last updated time
            if (document.getElementById('last-updated')) {
                document.getElementById('last-updated').textContent = data.formatted_time;
            }
            
            // Update gauges if they exist
            updateGauge('temp-gauge', data.temperature, 0, 40);
            updateGauge('humidity-gauge', data.humidity, 0, 100);
        })
        .catch(error => {
            console.error('Error fetching system status:', error);
        });
}

function updateStatusIndicator(elementId, status) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    if (status) {
        element.classList.remove('bg-secondary');
        element.classList.add('bg-success');
        element.classList.add('pulse-animation');
    } else {
        element.classList.remove('bg-success');
        element.classList.remove('pulse-animation');
        element.classList.add('bg-secondary');
    }
}

function updateTempClass(elementId, temperature) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    // Remove all temperature classes
    element.classList.remove('temp-cold', 'temp-cool', 'temp-normal', 'temp-warm', 'temp-hot');
    
    // Add appropriate class based on temperature
    if (temperature < 15) {
        element.classList.add('temp-cold');
    } else if (temperature < 20) {
        element.classList.add('temp-cool');
    } else if (temperature < 25) {
        element.classList.add('temp-normal');
    } else if (temperature < 30) {
        element.classList.add('temp-warm');
    } else {
        element.classList.add('temp-hot');
    }
}

// Control Buttons
function initControlButtons() {
    // Lights control
    setupControlButton('lights-on', 'lights', 'on');
    setupControlButton('lights-off', 'lights', 'off');
    setupControlButton('lights-auto', 'lights', 'auto');
    
    // AC control
    setupControlButton('ac-on', 'ac', 'on');
    setupControlButton('ac-off', 'ac', 'off');
    setupControlButton('ac-auto', 'ac', 'auto');
    
    // Fan control
    setupControlButton('fan-on', 'fan', 'on');
    setupControlButton('fan-off', 'fan', 'off');
    setupControlButton('fan-auto', 'fan', 'auto');
    
    // All devices control
    setupControlButton('all-on', 'all', 'on');
    setupControlButton('all-off', 'all', 'off');
    setupControlButton('all-auto', 'all', 'auto');
}

function setupControlButton(buttonId, device, action) {
    const button = document.getElementById(buttonId);
    if (!button) return;
    
    button.addEventListener('click', function() {
        sendControlCommand(device, action, button);
    });
}

function sendControlCommand(device, action, buttonElement) {
    // Disable button while processing
    if (buttonElement) {
        buttonElement.disabled = true;
    }
    
    fetch('/api/control', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            device: device,
            action: action
        }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Show success message
            showAlert('success', data.message);
            // Update status immediately
            updateSystemStatus();
        } else {
            // Show error message
            showAlert('danger', data.message || 'Error executing command');
        }
    })
    .catch(error => {
        console.error('Error sending control command:', error);
        showAlert('danger', 'Error communicating with the server');
    })
    .finally(() => {
        // Re-enable button
        if (buttonElement) {
            buttonElement.disabled = false;
        }
    });
}

// Energy Usage Chart
function initEnergyChart() {
    const ctx = document.getElementById('energyChart').getContext('2d');
    
    fetch('/api/energy')
        .then(response => response.json())
        .then(data => {
            // Prepare chart data
            const labels = data.map(item => item.date);
            const lightsData = data.map(item => item.lights_usage);
            const acData = data.map(item => item.ac_usage);
            const fanData = data.map(item => item.fan_usage);
            
            // Create chart
            const energyChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [
                        {
                            label: 'Lights (kWh)',
                            backgroundColor: '#FFC107',
                            data: lightsData
                        },
                        {
                            label: 'AC (kWh)',
                            backgroundColor: '#2196F3',
                            data: acData
                        },
                        {
                            label: 'Fan (kWh)',
                            backgroundColor: '#4CAF50',
                            data: fanData
                        }
                    ]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Energy Usage (kWh)'
                        }
                    },
                    scales: {
                        x: {
                            stacked: true,
                        },
                        y: {
                            stacked: true,
                            beginAtZero: true
                        }
                    }
                }
            });
        })
        .catch(error => {
            console.error('Error fetching energy data:', error);
        });
}

// Occupancy Chart
function initOccupancyChart() {
    const ctx = document.getElementById('occupancyChart').getContext('2d');
    
    fetch('/api/occupancy')
        .then(response => response.json())
        .then(data => {
            // Prepare chart data
            const labels = data.map(item => item.date);
            const occupancyData = data.map(item => item.total_occupied_time);
            
            // Create chart
            const occupancyChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [
                        {
                            label: 'Total Occupied Time (minutes)',
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 2,
                            pointBackgroundColor: 'rgba(75, 192, 192, 1)',
                            tension: 0.4,
                            fill: true,
                            data: occupancyData
                        }
                    ]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Daily Occupancy Duration (minutes)'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        })
        .catch(error => {
            console.error('Error fetching occupancy data:', error);
        });
}

// Sensor Gauges
function initSensorGauges() {
    // Initial update of the gauges
    updateGauge('temp-gauge', 22, 0, 40);
    updateGauge('humidity-gauge', 45, 0, 100);
}

function updateGauge(gaugeId, value, min, max) {
    const gauge = document.getElementById(gaugeId);
    if (!gauge) return;
    
    const fill = gauge.querySelector('.gauge-fill');
    const valueElement = gauge.querySelector('.gauge-value');
    
    if (fill && valueElement) {
        // Calculate the fill angle (180 degrees is the full range)
        const percentage = (value - min) / (max - min);
        const angle = percentage * 180;
        
        // Update the fill rotation
        fill.style.transform = `rotate(${angle}deg)`;
        
        // Update the value
        valueElement.textContent = value.toFixed(1);
    }
}

// Utility Functions
function showAlert(type, message) {
    // Create alert element
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.setAttribute('role', 'alert');
    
    // Add icon based on type
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'danger') icon = 'exclamation-triangle';
    if (type === 'warning') icon = 'exclamation-circle';
    
    alertDiv.innerHTML = `
        <i class="fas fa-${icon} alert-icon"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Find the alert container or create one
    let alertContainer = document.getElementById('alert-container');
    if (!alertContainer) {
        alertContainer = document.createElement('div');
        alertContainer.id = 'alert-container';
        alertContainer.className = 'alert-container';
        alertContainer.style.position = 'fixed';
        alertContainer.style.top = '20px';
        alertContainer.style.right = '20px';
        alertContainer.style.zIndex = '9999';
        alertContainer.style.maxWidth = '300px';
        document.body.appendChild(alertContainer);
    }
    
    // Add the alert to the container
    alertContainer.appendChild(alertDiv);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        alertDiv.classList.remove('show');
        setTimeout(() => {
            alertContainer.removeChild(alertDiv);
        }, 300);
    }, 5000);
}