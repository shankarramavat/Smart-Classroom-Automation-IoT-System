import threading
import time
import logging
from app import db
from models import SystemState, Log

logger = logging.getLogger(__name__)

class ApplianceController(threading.Thread):
    """
    Controls classroom appliances (lights, AC, fan) based on occupancy detection.
    - Turns on appliances 5 seconds after occupancy is detected
    - Turns off appliances 120 seconds after the room becomes unoccupied
    - Uses threading.Timer for non-blocking delays
    """
    
    def __init__(self, occupancy_detector, pir_sensor):
        """
        Initialize the appliance controller.
        
        Args:
            occupancy_detector: OccupancyDetector object
            pir_sensor: PIRSensorSimulation object for redundancy
        """
        threading.Thread.__init__(self)
        self.daemon = True
        self.occupancy_detector = occupancy_detector
        self.pir_sensor = pir_sensor
        self.running = False
        
        # Timers for delayed on/off
        self.turn_on_timer = None
        self.turn_off_timer = None
        
        # Delays in seconds
        self.turn_on_delay = 5.0
        self.turn_off_delay = 120.0
        
        # MQTT client for smart plugs
        self.mqtt_client = MQTTClientSimulation()
        
        # Manual override flags
        self.lights_override = None  # None = auto, True = on, False = off
        self.ac_override = None
        self.fan_override = None
        
        # Recover state from database
        self.recover_state()
    
    def run(self):
        """Main control loop that runs in a separate thread."""
        self.running = True
        logger.info("Starting appliance controller...")
        
        # Main loop - keep running until stopped
        while self.running:
            try:
                # Get current occupancy state
                cv_occupied = self.occupancy_detector.is_occupied()
                pir_motion = self.pir_sensor.is_motion_detected()
                
                # Consider the room occupied if either system detects occupancy
                room_occupied = cv_occupied or pir_motion
                
                # Update the system state in the database
                with db.app.app_context():
                    system_state = SystemState.query.order_by(SystemState.timestamp.desc()).first()
                    if not system_state:
                        system_state = SystemState()
                        db.session.add(system_state)
                    
                    system_state.occupancy = room_occupied
                    system_state.motion_detected = pir_motion
                    system_state.timestamp = time.time()
                    
                    # Simulate temperature and humidity readings
                    # In a real system, these would come from sensors
                    if system_state.ac:
                        # If AC is on, temperature decreases slowly
                        system_state.temperature = max(20.0, system_state.temperature - 0.1)
                    else:
                        # If AC is off, temperature increases slowly if room is occupied
                        if room_occupied:
                            system_state.temperature = min(30.0, system_state.temperature + 0.05)
                        
                    # Humidity varies slightly
                    if system_state.fan:
                        system_state.humidity = max(30.0, system_state.humidity - 0.1)
                    else:
                        if room_occupied:
                            system_state.humidity = min(60.0, system_state.humidity + 0.05)
                    
                    db.session.commit()
                
                # Handle occupancy state changes
                if room_occupied:
                    # Cancel any pending turn-off timer
                    if self.turn_off_timer is not None:
                        self.turn_off_timer.cancel()
                        self.turn_off_timer = None
                        logger.info("Canceled appliance turn-off timer due to detected occupancy")
                    
                    # Start a turn-on timer if not already running
                    if self.turn_on_timer is None:
                        logger.info(f"Starting appliance turn-on timer ({self.turn_on_delay}s)")
                        self.turn_on_timer = threading.Timer(self.turn_on_delay, self.turn_on_appliances)
                        self.turn_on_timer.daemon = True
                        self.turn_on_timer.start()
                else:
                    # Cancel any pending turn-on timer
                    if self.turn_on_timer is not None:
                        self.turn_on_timer.cancel()
                        self.turn_on_timer = None
                        logger.info("Canceled appliance turn-on timer due to vacant room")
                    
                    # Start a turn-off timer if not already running
                    if self.turn_off_timer is None:
                        logger.info(f"Starting appliance turn-off timer ({self.turn_off_delay}s)")
                        self.turn_off_timer = threading.Timer(self.turn_off_delay, self.turn_off_appliances)
                        self.turn_off_timer.daemon = True
                        self.turn_off_timer.start()
                
                # Sleep for a short while
                time.sleep(1.0)
                
            except Exception as e:
                logger.error(f"Error in appliance control loop: {e}")
                time.sleep(5.0)  # Sleep longer on error
    
    def turn_on_appliances(self):
        """Turn on all appliances with consideration for manual overrides."""
        logger.info("Turning on appliances due to sustained occupancy")
        
        # Reset the timer reference
        self.turn_on_timer = None
        
        # Process each appliance, respecting manual overrides
        with db.app.app_context():
            system_state = SystemState.query.order_by(SystemState.timestamp.desc()).first()
            if not system_state:
                system_state = SystemState()
                db.session.add(system_state)
            
            # Lights
            if self.lights_override is None:  # Auto mode
                if not system_state.lights:  # Only if currently off
                    system_state.lights = True
                    self.toggle_gpio_relay('lights', True)
                    self.log_event('LIGHTS_ON', 'Automatic: Room occupied')
            elif self.lights_override:  # Forced on
                if not system_state.lights:  # Only if currently off
                    system_state.lights = True
                    self.toggle_gpio_relay('lights', True)
                    self.log_event('LIGHTS_ON', 'Manual override: ON')
            
            # AC
            if self.ac_override is None:  # Auto mode
                if not system_state.ac:  # Only if currently off
                    system_state.ac = True
                    self.toggle_gpio_relay('ac', True)
                    self.log_event('AC_ON', 'Automatic: Room occupied')
            elif self.ac_override:  # Forced on
                if not system_state.ac:  # Only if currently off
                    system_state.ac = True
                    self.toggle_gpio_relay('ac', True)
                    self.log_event('AC_ON', 'Manual override: ON')
            
            # Fan
            if self.fan_override is None:  # Auto mode
                if not system_state.fan:  # Only if currently off
                    system_state.fan = True
                    self.toggle_gpio_relay('fan', True)
                    self.log_event('FAN_ON', 'Automatic: Room occupied')
            elif self.fan_override:  # Forced on
                if not system_state.fan:  # Only if currently off
                    system_state.fan = True
                    self.toggle_gpio_relay('fan', True)
                    self.log_event('FAN_ON', 'Manual override: ON')
            
            db.session.commit()
    
    def turn_off_appliances(self):
        """Turn off all appliances with consideration for manual overrides."""
        logger.info("Turning off appliances due to sustained vacancy")
        
        # Reset the timer reference
        self.turn_off_timer = None
        
        # Process each appliance, respecting manual overrides
        with db.app.app_context():
            system_state = SystemState.query.order_by(SystemState.timestamp.desc()).first()
            if not system_state:
                system_state = SystemState()
                db.session.add(system_state)
            
            # Lights
            if self.lights_override is None:  # Auto mode
                if system_state.lights:  # Only if currently on
                    system_state.lights = False
                    self.toggle_gpio_relay('lights', False)
                    self.log_event('LIGHTS_OFF', 'Automatic: Room vacant')
            elif not self.lights_override:  # Forced off
                if system_state.lights:  # Only if currently on
                    system_state.lights = False
                    self.toggle_gpio_relay('lights', False)
                    self.log_event('LIGHTS_OFF', 'Manual override: OFF')
            
            # AC
            if self.ac_override is None:  # Auto mode
                if system_state.ac:  # Only if currently on
                    system_state.ac = False
                    self.toggle_gpio_relay('ac', False)
                    self.log_event('AC_OFF', 'Automatic: Room vacant')
            elif not self.ac_override:  # Forced off
                if system_state.ac:  # Only if currently on
                    system_state.ac = False
                    self.toggle_gpio_relay('ac', False)
                    self.log_event('AC_OFF', 'Manual override: OFF')
            
            # Fan
            if self.fan_override is None:  # Auto mode
                if system_state.fan:  # Only if currently on
                    system_state.fan = False
                    self.toggle_gpio_relay('fan', False)
                    self.log_event('FAN_OFF', 'Automatic: Room vacant')
            elif not self.fan_override:  # Forced off
                if system_state.fan:  # Only if currently on
                    system_state.fan = False
                    self.toggle_gpio_relay('fan', False)
                    self.log_event('FAN_OFF', 'Manual override: OFF')
            
            db.session.commit()
    
    def toggle_gpio_relay(self, device, state):
        """
        Simulate toggling a GPIO relay for an appliance.
        
        Args:
            device: The appliance to control ('lights', 'ac', 'fan')
            state: True to turn on, False to turn off
        """
        # In a real system, we would control GPIO pins here
        # For this simulation, we'll just log the action and use MQTT
        command = 'on' if state else 'off'
        logger.info(f"GPIO RELAY: {device.upper()} turned {command}")
        
        # Send command to smart plug via MQTT
        self.mqtt_client.send_command(device, command)
    
    def log_event(self, event_type, details):
        """Log an event to the database."""
        with db.app.app_context():
            log_entry = Log(
                event=event_type,
                details=details
            )
            db.session.add(log_entry)
            db.session.commit()
    
    def recover_state(self):
        """Recover the appliance state from the database after a power loss."""
        try:
            # Get the current system state from the database
            with db.app.app_context():
                system_state = SystemState.query.order_by(SystemState.timestamp.desc()).first()
                
                if system_state:
                    # If the room is occupied, turn on appliances after a short delay
                    if system_state.occupancy:
                        logger.info("Recovering state: Room was occupied before restart")
                        if self.turn_on_timer is None:
                            self.turn_on_timer = threading.Timer(5.0, self.turn_on_appliances)
                            self.turn_on_timer.daemon = True
                            self.turn_on_timer.start()
                
                    # Restore the actual appliance states
                    if system_state.lights:
                        self.toggle_gpio_relay('lights', True)
                    
                    if system_state.ac:
                        self.toggle_gpio_relay('ac', True)
                    
                    if system_state.fan:
                        self.toggle_gpio_relay('fan', True)
                    
                    self.log_event('SYSTEM_RESTART', 'Appliance controller restarted, state recovered')
                else:
                    # No state found, create an initial state
                    system_state = SystemState()
                    with db.app.app_context():
                        db.session.add(system_state)
                        db.session.commit()
                    self.log_event('SYSTEM_INIT', 'Initial system state created')
                    
        except Exception as e:
            logger.error(f"Error recovering state: {e}")
    
    def manual_override_lights(self, state):
        """
        Manually override the lights state.
        
        Args:
            state: True to force on, False to force off, None to return to auto
        """
        self.lights_override = state
        logger.info(f"Manual override for lights: {state if state is not None else 'AUTO'}")
        
        if state is True:
            self.turn_on_appliances()  # This will only affect lights due to override
        elif state is False:
            self.turn_off_appliances()  # This will only affect lights due to override
    
    def manual_override_ac(self, state):
        """
        Manually override the AC state.
        
        Args:
            state: True to force on, False to force off, None to return to auto
        """
        self.ac_override = state
        logger.info(f"Manual override for AC: {state if state is not None else 'AUTO'}")
        
        if state is True:
            self.turn_on_appliances()  # This will only affect AC due to override
        elif state is False:
            self.turn_off_appliances()  # This will only affect AC due to override
    
    def manual_override_fan(self, state):
        """
        Manually override the fan state.
        
        Args:
            state: True to force on, False to force off, None to return to auto
        """
        self.fan_override = state
        logger.info(f"Manual override for fan: {state if state is not None else 'AUTO'}")
        
        if state is True:
            self.turn_on_appliances()  # This will only affect fan due to override
        elif state is False:
            self.turn_off_appliances()  # This will only affect fan due to override
    
    def manual_override_all(self, state):
        """
        Manually override all appliances.
        
        Args:
            state: True to force on, False to force off, None to return to auto
        """
        self.lights_override = state
        self.ac_override = state
        self.fan_override = state
        logger.info(f"Manual override for all appliances: {state if state is not None else 'AUTO'}")
        
        if state is True:
            self.turn_on_appliances()
        elif state is False:
            self.turn_off_appliances()
    
    def stop(self):
        """Stop the controller thread and cancel any pending timers."""
        self.running = False
        
        if self.turn_on_timer is not None:
            self.turn_on_timer.cancel()
            
        if self.turn_off_timer is not None:
            self.turn_off_timer.cancel()

class MQTTClientSimulation:
    """
    Simulates an MQTT client for controlling smart plugs.
    In a real implementation, this would use a library like paho-mqtt.
    """
    
    def __init__(self):
        # In a real system, we would initialize the MQTT client here
        logger.info("Initializing MQTT client for smart plug control")
    
    def send_command(self, device, command):
        """
        Simulate sending an MQTT command to a smart plug.
        
        Args:
            device: The device to control ('lights', 'ac', 'fan')
            command: The command to send ('on' or 'off')
        """
        # In a real system, we would send the MQTT message here
        logger.info(f"MQTT: Publishing {command} command to {device} topic")