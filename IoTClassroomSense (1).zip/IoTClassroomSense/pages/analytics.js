import { useState, useEffect } from 'react';
import Head from 'next/head';
import { 
  Container, 
  Box, 
  Typography, 
  Paper, 
  Button,
  Grid,
  Card,
  CardContent,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  CircularProgress,
  Alert,
  Divider,
  Tabs,
  Tab,
  Stack,
  Chip
} from '@mui/material';
import { 
  ArrowBack,
  Refresh,
  DateRange,
  BarChart as BarChartIcon,
  PieChart as PieChartIcon,
  TrendingUp,
  AttachMoney,
  Bolt,
  Lightbulb,
  AcUnit,
  Air
} from '@mui/icons-material';
import { ThemeProvider } from '@mui/material/styles';
import theme from '../styles/theme';
import axios from 'axios';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  PointElement, 
  LineElement, 
  BarElement,
  ArcElement,
  Title, 
  Tooltip, 
  Legend,
  Filler
} from 'chart.js';
import { Line, Bar, Pie } from 'react-chartjs-2';

// Register Chart.js components
ChartJS.register(
  CategoryScale, 
  LinearScale, 
  PointElement, 
  LineElement, 
  BarElement,
  ArcElement,
  Title, 
  Tooltip, 
  Legend,
  Filler
);

export default function AnalyticsPage() {
  // State for tab selection
  const [tabValue, setTabValue] = useState(0);
  
  // State for energy data
  const [energyData, setEnergyData] = useState(null);
  const [energyLoading, setEnergyLoading] = useState(true);
  const [energyError, setEnergyError] = useState(null);
  
  // State for occupancy data
  const [occupancyData, setOccupancyData] = useState(null);
  const [occupancyLoading, setOccupancyLoading] = useState(true);
  const [occupancyError, setOccupancyError] = useState(null);
  
  // Filter states
  const [dateRange, setDateRange] = useState({
    start_date: getDateXDaysAgo(30), // Default to last 30 days
    end_date: getCurrentDate()
  });
  const [groupBy, setGroupBy] = useState('day');
  
  // Fetch energy data
  const fetchEnergyData = async () => {
    setEnergyLoading(true);
    try {
      const response = await axios.get('/api/energy', {
        params: dateRange
      });
      setEnergyData(response.data);
      setEnergyLoading(false);
    } catch (err) {
      console.error('Error fetching energy data:', err);
      setEnergyError('Failed to load energy data. Please check your connection.');
      setEnergyLoading(false);
    }
  };
  
  // Fetch occupancy data
  const fetchOccupancyData = async () => {
    setOccupancyLoading(true);
    try {
      const response = await axios.get('/api/occupancy/analytics', {
        params: {
          ...dateRange,
          group_by: groupBy
        }
      });
      setOccupancyData(response.data);
      setOccupancyLoading(false);
    } catch (err) {
      console.error('Error fetching occupancy data:', err);
      setOccupancyError('Failed to load occupancy data. Please check your connection.');
      setOccupancyLoading(false);
    }
  };
  
  // Initialize and fetch data
  useEffect(() => {
    fetchEnergyData();
    fetchOccupancyData();
  }, [dateRange, groupBy]);
  
  // Handle tab change
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };
  
  // Handle date range change
  const handleDateRangeChange = (field, value) => {
    setDateRange(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  // Handle group by change
  const handleGroupByChange = (event) => {
    setGroupBy(event.target.value);
  };
  
  // Refresh data
  const handleRefresh = () => {
    fetchEnergyData();
    fetchOccupancyData();
  };
  
  // Prepare energy chart data
  const prepareEnergyChartData = () => {
    if (!energyData || !energyData.data || energyData.data.length === 0) {
      return null;
    }
    
    const labels = energyData.data.map(item => {
      const date = new Date(item.date);
      return date.toLocaleDateString();
    });
    
    return {
      labels,
      datasets: [
        {
          label: 'Lights (kWh)',
          data: energyData.data.map(item => item.lights_usage),
          backgroundColor: 'rgba(255, 153, 51, 0.5)',
          borderColor: '#FF9933',
          yAxisID: 'y',
        },
        {
          label: 'AC (kWh)',
          data: energyData.data.map(item => item.ac_usage),
          backgroundColor: 'rgba(0, 0, 205, 0.5)',
          borderColor: '#0000CD',
          yAxisID: 'y',
        },
        {
          label: 'Fan (kWh)',
          data: energyData.data.map(item => item.fan_usage),
          backgroundColor: 'rgba(19, 136, 8, 0.5)',
          borderColor: '#138808',
          yAxisID: 'y',
        }
      ]
    };
  };
  
  // Prepare energy cost chart data
  const prepareEnergyCostChartData = () => {
    if (!energyData || !energyData.data || energyData.data.length === 0) {
      return null;
    }
    
    const labels = energyData.data.map(item => {
      const date = new Date(item.date);
      return date.toLocaleDateString();
    });
    
    return {
      labels,
      datasets: [
        {
          label: 'Daily Cost (₹)',
          data: energyData.data.map(item => item.cost),
          backgroundColor: 'rgba(66, 165, 245, 0.5)',
          borderColor: '#42A5F5',
          borderWidth: 1,
          fill: true,
        }
      ]
    };
  };
  
  // Prepare energy distribution chart data
  const prepareEnergyDistributionChartData = () => {
    if (!energyData || !energyData.data || energyData.data.length === 0) {
      return null;
    }
    
    // Sum up usage by device
    const totalLights = energyData.data.reduce((sum, item) => sum + item.lights_usage, 0);
    const totalAC = energyData.data.reduce((sum, item) => sum + item.ac_usage, 0);
    const totalFan = energyData.data.reduce((sum, item) => sum + item.fan_usage, 0);
    
    return {
      labels: ['Lights', 'AC', 'Fan'],
      datasets: [
        {
          data: [totalLights, totalAC, totalFan],
          backgroundColor: ['#FF9933', '#0000CD', '#138808'],
          hoverBackgroundColor: ['#FFB266', '#3366FF', '#26A69A'],
          borderWidth: 1,
        }
      ]
    };
  };
  
  // Prepare occupancy chart data
  const prepareOccupancyChartData = () => {
    if (!occupancyData || !occupancyData.data || occupancyData.data.length === 0) {
      return null;
    }
    
    let labels = [];
    let data = [];
    
    if (groupBy === 'day') {
      labels = occupancyData.data.map(item => {
        const date = new Date(item.date);
        return date.toLocaleDateString();
      });
      data = occupancyData.data.map(item => item.total_occupied_time);
    } else if (groupBy === 'week') {
      labels = occupancyData.data.map(item => item.period);
      data = occupancyData.data.map(item => item.avg_occupied_time);
    } else if (groupBy === 'month') {
      labels = occupancyData.data.map(item => item.period);
      data = occupancyData.data.map(item => item.avg_occupied_time);
    }
    
    return {
      labels,
      datasets: [
        {
          label: groupBy === 'day' ? 'Total Occupied Time (min)' : 'Avg. Occupied Time (min)',
          data,
          backgroundColor: 'rgba(102, 187, 106, 0.5)',
          borderColor: '#66BB6A',
          borderWidth: 1,
          fill: true,
        }
      ]
    };
  };
  
  // Prepare day of week distribution chart data
  const prepareDayOfWeekChartData = () => {
    if (!occupancyData || !occupancyData.day_of_week_distribution) {
      return null;
    }
    
    const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const data = dayNames.map(day => occupancyData.day_of_week_distribution[day] || 0);
    
    return {
      labels: dayNames,
      datasets: [
        {
          label: 'Avg. Occupied Time by Day (min)',
          data,
          backgroundColor: [
            'rgba(255, 99, 132, 0.5)',
            'rgba(255, 159, 64, 0.5)',
            'rgba(255, 205, 86, 0.5)',
            'rgba(75, 192, 192, 0.5)',
            'rgba(54, 162, 235, 0.5)',
            'rgba(153, 102, 255, 0.5)',
            'rgba(201, 203, 207, 0.5)'
          ],
          borderColor: [
            'rgb(255, 99, 132)',
            'rgb(255, 159, 64)',
            'rgb(255, 205, 86)',
            'rgb(75, 192, 192)',
            'rgb(54, 162, 235)',
            'rgb(153, 102, 255)',
            'rgb(201, 203, 207)'
          ],
          borderWidth: 1
        }
      ]
    };
  };
  
  return (
    <ThemeProvider theme={theme}>
      <Head>
        <title>Analytics | IoT Classroom Automation</title>
        <meta name="description" content="Analytics dashboard for smart classroom automation" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Box sx={{ mb: 4 }}>
          <Button 
            variant="outlined" 
            startIcon={<ArrowBack />} 
            href="/"
            sx={{ mb: 2 }}
          >
            Back to Dashboard
          </Button>
          <Typography variant="h4" component="h1" gutterBottom>
            Analytics Dashboard
          </Typography>
          <Typography variant="body1" color="text.secondary" paragraph>
            View energy usage and occupancy patterns
          </Typography>
        </Box>
        
        {/* Filters */}
        <Paper sx={{ p: 2, mb: 3 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={2}>
              <DateRange color="primary" sx={{ mr: 1 }} />
              <Typography variant="subtitle1" component="span">
                Date Range
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField
                label="Start Date"
                type="date"
                fullWidth
                value={dateRange.start_date}
                onChange={(e) => handleDateRangeChange('start_date', e.target.value)}
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField
                label="End Date"
                type="date"
                fullWidth
                value={dateRange.end_date}
                onChange={(e) => handleDateRangeChange('end_date', e.target.value)}
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={2}>
              <FormControl fullWidth>
                <InputLabel id="group-by-label">Group By</InputLabel>
                <Select
                  labelId="group-by-label"
                  id="group-by"
                  value={groupBy}
                  label="Group By"
                  onChange={handleGroupByChange}
                >
                  <MenuItem value="day">Day</MenuItem>
                  <MenuItem value="week">Week</MenuItem>
                  <MenuItem value="month">Month</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6} md={2}>
              <Button 
                variant="contained" 
                color="primary" 
                startIcon={<Refresh />} 
                fullWidth
                onClick={handleRefresh}
              >
                Refresh
              </Button>
            </Grid>
          </Grid>
        </Paper>
        
        {/* Analytics Tabs */}
        <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
          <Tabs 
            value={tabValue} 
            onChange={handleTabChange} 
            aria-label="analytics tabs"
            textColor="primary"
            indicatorColor="primary"
          >
            <Tab 
              icon={<Bolt />} 
              label="Energy Usage" 
              id="tab-0" 
              aria-controls="tabpanel-0" 
            />
            <Tab 
              icon={<TrendingUp />} 
              label="Occupancy Patterns" 
              id="tab-1" 
              aria-controls="tabpanel-1" 
            />
          </Tabs>
        </Box>
        
        {/* Energy Usage Tab */}
        <div
          role="tabpanel"
          hidden={tabValue !== 0}
          id="tabpanel-0"
          aria-labelledby="tab-0"
        >
          {tabValue === 0 && (
            <>
              {energyLoading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
                  <CircularProgress />
                </Box>
              ) : energyError ? (
                <Alert severity="error" sx={{ mb: 3 }}>
                  {energyError}
                </Alert>
              ) : !energyData || energyData.data.length === 0 ? (
                <Alert severity="info" sx={{ mb: 3 }}>
                  No energy data available for the selected date range.
                </Alert>
              ) : (
                <>
                  {/* Energy Usage Summary */}
                  <Grid container spacing={3} sx={{ mb: 4 }}>
                    <Grid item xs={12} sm={6} md={3}>
                      <Card sx={{ height: '100%' }}>
                        <CardContent>
                          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                            <Bolt sx={{ color: 'primary.main', mr: 1, fontSize: 28 }} />
                            <Typography variant="h6">Total Energy</Typography>
                          </Box>
                          <Typography variant="h4" component="div" gutterBottom>
                            {energyData.summary.total_usage.toFixed(2)} kWh
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            For the selected period
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12} sm={6} md={3}>
                      <Card sx={{ height: '100%' }}>
                        <CardContent>
                          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                            <AttachMoney sx={{ color: 'secondary.main', mr: 1, fontSize: 28 }} />
                            <Typography variant="h6">Total Cost</Typography>
                          </Box>
                          <Typography variant="h4" component="div" gutterBottom>
                            <span className="inr-symbol">₹</span>{energyData.summary.total_cost.toFixed(2)}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Estimated electrical charges
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12} sm={6} md={3}>
                      <Card sx={{ height: '100%' }}>
                        <CardContent>
                          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                            <Lightbulb sx={{ color: 'primary.main', mr: 1, fontSize: 28 }} />
                            <Typography variant="h6">Lights Usage</Typography>
                          </Box>
                          <Typography variant="h4" component="div" gutterBottom>
                            {energyData.data.reduce((sum, item) => sum + item.lights_usage, 0).toFixed(2)} kWh
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {((energyData.data.reduce((sum, item) => sum + item.lights_usage, 0) / energyData.summary.total_usage) * 100).toFixed(1)}% of total
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12} sm={6} md={3}>
                      <Card sx={{ height: '100%' }}>
                        <CardContent>
                          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                            <AcUnit sx={{ color: 'tertiary.main', mr: 1, fontSize: 28 }} />
                            <Typography variant="h6">AC Usage</Typography>
                          </Box>
                          <Typography variant="h4" component="div" gutterBottom>
                            {energyData.data.reduce((sum, item) => sum + item.ac_usage, 0).toFixed(2)} kWh
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {((energyData.data.reduce((sum, item) => sum + item.ac_usage, 0) / energyData.summary.total_usage) * 100).toFixed(1)}% of total
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                  </Grid>
                  
                  {/* Energy Usage Chart */}
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={8}>
                      <Card sx={{ p: 2, mb: 3 }}>
                        <Typography variant="h6" gutterBottom>
                          <BarChartIcon sx={{ verticalAlign: 'middle', mr: 1 }} />
                          Energy Usage Over Time
                        </Typography>
                        <Divider sx={{ mb: 2 }} />
                        <Box sx={{ height: 400 }}>
                          <Bar 
                            data={prepareEnergyChartData()} 
                            options={{
                              responsive: true,
                              maintainAspectRatio: false,
                              scales: {
                                x: {
                                  stacked: true,
                                },
                                y: {
                                  stacked: true,
                                  title: {
                                    display: true,
                                    text: 'Energy Usage (kWh)'
                                  }
                                }
                              },
                              plugins: {
                                legend: {
                                  position: 'top',
                                },
                                tooltip: {
                                  callbacks: {
                                    label: function(context) {
                                      return `${context.dataset.label}: ${context.raw.toFixed(2)} kWh`;
                                    }
                                  }
                                }
                              }
                            }}
                          />
                        </Box>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12} md={4}>
                      <Card sx={{ p: 2, mb: 3 }}>
                        <Typography variant="h6" gutterBottom>
                          <PieChartIcon sx={{ verticalAlign: 'middle', mr: 1 }} />
                          Energy Distribution
                        </Typography>
                        <Divider sx={{ mb: 2 }} />
                        <Box sx={{ height: 400, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                          <Pie 
                            data={prepareEnergyDistributionChartData()} 
                            options={{
                              responsive: true,
                              maintainAspectRatio: false,
                              plugins: {
                                legend: {
                                  position: 'bottom',
                                },
                                tooltip: {
                                  callbacks: {
                                    label: function(context) {
                                      const value = context.raw;
                                      const total = context.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                                      const percentage = ((value / total) * 100).toFixed(1);
                                      return `${context.label}: ${value.toFixed(2)} kWh (${percentage}%)`;
                                    }
                                  }
                                }
                              }
                            }}
                          />
                        </Box>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12}>
                      <Card sx={{ p: 2 }}>
                        <Typography variant="h6" gutterBottom>
                          <AttachMoney sx={{ verticalAlign: 'middle', mr: 1 }} />
                          Daily Energy Cost
                        </Typography>
                        <Divider sx={{ mb: 2 }} />
                        <Box sx={{ height: 300 }}>
                          <Line 
                            data={prepareEnergyCostChartData()} 
                            options={{
                              responsive: true,
                              maintainAspectRatio: false,
                              scales: {
                                y: {
                                  title: {
                                    display: true,
                                    text: 'Cost (₹)'
                                  },
                                  beginAtZero: true
                                }
                              },
                              plugins: {
                                legend: {
                                  position: 'top',
                                },
                                tooltip: {
                                  callbacks: {
                                    label: function(context) {
                                      return `Cost: ₹${context.raw.toFixed(2)}`;
                                    }
                                  }
                                }
                              }
                            }}
                          />
                        </Box>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12}>
                      <Card sx={{ p: 2 }}>
                        <Typography variant="h6" gutterBottom>
                          Energy Efficiency Insights
                        </Typography>
                        <Divider sx={{ mb: 2 }} />
                        <Grid container spacing={2}>
                          <Grid item xs={12} md={4}>
                            <Paper sx={{ p: 2, bgcolor: 'background.paper', borderLeft: '4px solid', borderColor: 'primary.main' }}>
                              <Typography variant="subtitle1" gutterBottom>Highest Energy Usage</Typography>
                              <Typography variant="body2" paragraph>
                                {energyData.data.length > 0 && (
                                  <>
                                    {(() => {
                                      const maxUsageItem = energyData.data.reduce((max, item) => 
                                        item.total_usage > max.total_usage ? item : max, energyData.data[0]);
                                      return (
                                        <>
                                          <strong>{new Date(maxUsageItem.date).toLocaleDateString()}</strong>: 
                                          {' '}{maxUsageItem.total_usage.toFixed(2)} kWh (₹{maxUsageItem.cost.toFixed(2)})
                                        </>
                                      );
                                    })()}
                                  </>
                                )}
                              </Typography>
                            </Paper>
                          </Grid>
                          <Grid item xs={12} md={4}>
                            <Paper sx={{ p: 2, bgcolor: 'background.paper', borderLeft: '4px solid', borderColor: 'secondary.main' }}>
                              <Typography variant="subtitle1" gutterBottom>Most Efficient Day</Typography>
                              <Typography variant="body2" paragraph>
                                {energyData.data.length > 0 && (
                                  <>
                                    {(() => {
                                      // Find the day with usage > 0 but lowest value
                                      const nonZeroItems = energyData.data.filter(item => item.total_usage > 0);
                                      if (nonZeroItems.length === 0) return "No usage data available";
                                      
                                      const minUsageItem = nonZeroItems.reduce((min, item) => 
                                        item.total_usage < min.total_usage ? item : min, nonZeroItems[0]);
                                      return (
                                        <>
                                          <strong>{new Date(minUsageItem.date).toLocaleDateString()}</strong>: 
                                          {' '}{minUsageItem.total_usage.toFixed(2)} kWh (₹{minUsageItem.cost.toFixed(2)})
                                        </>
                                      );
                                    })()}
                                  </>
                                )}
                              </Typography>
                            </Paper>
                          </Grid>
                          <Grid item xs={12} md={4}>
                            <Paper sx={{ p: 2, bgcolor: 'background.paper', borderLeft: '4px solid', borderColor: 'info.main' }}>
                              <Typography variant="subtitle1" gutterBottom>Average Daily Consumption</Typography>
                              <Typography variant="body2" paragraph>
                                {energyData.data.length > 0 && (
                                  <>
                                    {(() => {
                                      const avgUsage = energyData.summary.total_usage / energyData.data.length;
                                      const avgCost = energyData.summary.total_cost / energyData.data.length;
                                      return (
                                        <>
                                          <strong>{avgUsage.toFixed(2)} kWh</strong> per day
                                          <br />
                                          Average cost: ₹{avgCost.toFixed(2)} per day
                                        </>
                                      );
                                    })()}
                                  </>
                                )}
                              </Typography>
                            </Paper>
                          </Grid>
                        </Grid>
                      </Card>
                    </Grid>
                  </Grid>
                </>
              )}
            </>
          )}
        </div>
        
        {/* Occupancy Patterns Tab */}
        <div
          role="tabpanel"
          hidden={tabValue !== 1}
          id="tabpanel-1"
          aria-labelledby="tab-1"
        >
          {tabValue === 1 && (
            <>
              {occupancyLoading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
                  <CircularProgress />
                </Box>
              ) : occupancyError ? (
                <Alert severity="error" sx={{ mb: 3 }}>
                  {occupancyError}
                </Alert>
              ) : !occupancyData || occupancyData.data.length === 0 ? (
                <Alert severity="info" sx={{ mb: 3 }}>
                  No occupancy data available for the selected date range.
                </Alert>
              ) : (
                <>
                  {/* Occupancy Summary */}
                  <Grid container spacing={3} sx={{ mb: 4 }}>
                    <Grid item xs={12} md={4}>
                      <Card>
                        <CardContent>
                          <Typography variant="h6" gutterBottom>
                            Average Daily Occupancy
                          </Typography>
                          <Typography variant="h3" gutterBottom>
                            {(() => {
                              if (groupBy === 'day') {
                                const totalTime = occupancyData.data.reduce(
                                  (sum, item) => sum + item.total_occupied_time, 0
                                );
                                return (totalTime / occupancyData.data.length).toFixed(1);
                              } else {
                                const totalTime = occupancyData.data.reduce(
                                  (sum, item) => sum + item.avg_occupied_time, 0
                                );
                                return (totalTime / occupancyData.data.length).toFixed(1);
                              }
                            })()} min
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Average time the classroom is occupied per day
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12} md={4}>
                      <Card>
                        <CardContent>
                          <Typography variant="h6" gutterBottom>
                            Peak Occupancy Day
                          </Typography>
                          <Typography variant="h3" gutterBottom>
                            {(() => {
                              if (occupancyData.day_of_week_distribution) {
                                const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                                const maxDay = days.reduce((max, day) => 
                                  occupancyData.day_of_week_distribution[day] > 
                                  occupancyData.day_of_week_distribution[max] ? day : max, days[0]);
                                return maxDay;
                              }
                              return 'N/A';
                            })()}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Day with highest average occupancy time
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12} md={4}>
                      <Card>
                        <CardContent>
                          <Typography variant="h6" gutterBottom>
                            Total Data Points
                          </Typography>
                          <Typography variant="h3" gutterBottom>
                            {occupancyData.data.length}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Number of days with occupancy data
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                  </Grid>
                  
                  {/* Occupancy Charts */}
                  <Grid container spacing={3}>
                    <Grid item xs={12}>
                      <Card sx={{ p: 2, mb: 3 }}>
                        <Typography variant="h6" gutterBottom>
                          <TrendingUp sx={{ verticalAlign: 'middle', mr: 1 }} />
                          Occupancy Time Trend
                        </Typography>
                        <Divider sx={{ mb: 2 }} />
                        <Box sx={{ height: 400 }}>
                          <Bar 
                            data={prepareOccupancyChartData()} 
                            options={{
                              responsive: true,
                              maintainAspectRatio: false,
                              scales: {
                                y: {
                                  title: {
                                    display: true,
                                    text: 'Occupied Time (minutes)'
                                  },
                                  beginAtZero: true
                                }
                              },
                              plugins: {
                                legend: {
                                  position: 'top',
                                },
                                tooltip: {
                                  callbacks: {
                                    label: function(context) {
                                      return `${context.dataset.label}: ${context.raw.toFixed(1)} min`;
                                    }
                                  }
                                }
                              }
                            }}
                          />
                        </Box>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12}>
                      <Card sx={{ p: 2, mb: 3 }}>
                        <Typography variant="h6" gutterBottom>
                          <BarChartIcon sx={{ verticalAlign: 'middle', mr: 1 }} />
                          Occupancy by Day of Week
                        </Typography>
                        <Divider sx={{ mb: 2 }} />
                        <Box sx={{ height: 400 }}>
                          <Bar 
                            data={prepareDayOfWeekChartData()} 
                            options={{
                              responsive: true,
                              maintainAspectRatio: false,
                              indexAxis: 'y',
                              scales: {
                                x: {
                                  title: {
                                    display: true,
                                    text: 'Average Occupied Time (minutes)'
                                  },
                                  beginAtZero: true
                                }
                              },
                              plugins: {
                                legend: {
                                  display: false,
                                },
                                tooltip: {
                                  callbacks: {
                                    label: function(context) {
                                      return `Avg. Occupancy: ${context.raw.toFixed(1)} min`;
                                    }
                                  }
                                }
                              }
                            }}
                          />
                        </Box>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12}>
                      <Card sx={{ p: 2 }}>
                        <Typography variant="h6" gutterBottom>
                          Occupancy Insights
                        </Typography>
                        <Divider sx={{ mb: 2 }} />
                        <Grid container spacing={2}>
                          <Grid item xs={12} md={4}>
                            <Paper sx={{ p: 2, bgcolor: 'background.paper', borderLeft: '4px solid', borderColor: 'success.main' }}>
                              <Typography variant="subtitle1" gutterBottom>Highest Occupancy</Typography>
                              <Typography variant="body2" paragraph>
                                {occupancyData.data.length > 0 && (
                                  <>
                                    {(() => {
                                      const maxOccupancyItem = occupancyData.data.reduce((max, item) => {
                                        const itemValue = groupBy === 'day' ? 
                                          item.total_occupied_time : item.avg_occupied_time;
                                        const maxValue = groupBy === 'day' ? 
                                          max.total_occupied_time : max.avg_occupied_time;
                                        return itemValue > maxValue ? item : max;
                                      }, occupancyData.data[0]);
                                      
                                      const label = groupBy === 'day' ? 
                                        new Date(maxOccupancyItem.date).toLocaleDateString() :
                                        maxOccupancyItem.period;
                                      
                                      const value = groupBy === 'day' ? 
                                        maxOccupancyItem.total_occupied_time : 
                                        maxOccupancyItem.avg_occupied_time;
                                      
                                      return (
                                        <>
                                          <strong>{label}</strong>: {value.toFixed(1)} minutes
                                          {groupBy !== 'day' && ` (avg. per day)`}
                                        </>
                                      );
                                    })()}
                                  </>
                                )}
                              </Typography>
                            </Paper>
                          </Grid>
                          <Grid item xs={12} md={4}>
                            <Paper sx={{ p: 2, bgcolor: 'background.paper', borderLeft: '4px solid', borderColor: 'error.main' }}>
                              <Typography variant="subtitle1" gutterBottom>Lowest Occupancy</Typography>
                              <Typography variant="body2" paragraph>
                                {occupancyData.data.length > 0 && (
                                  <>
                                    {(() => {
                                      const minOccupancyItem = occupancyData.data.reduce((min, item) => {
                                        const itemValue = groupBy === 'day' ? 
                                          item.total_occupied_time : item.avg_occupied_time;
                                        const minValue = groupBy === 'day' ? 
                                          min.total_occupied_time : min.avg_occupied_time;
                                        return itemValue < minValue ? item : min;
                                      }, occupancyData.data[0]);
                                      
                                      const label = groupBy === 'day' ? 
                                        new Date(minOccupancyItem.date).toLocaleDateString() :
                                        minOccupancyItem.period;
                                      
                                      const value = groupBy === 'day' ? 
                                        minOccupancyItem.total_occupied_time : 
                                        minOccupancyItem.avg_occupied_time;
                                      
                                      return (
                                        <>
                                          <strong>{label}</strong>: {value.toFixed(1)} minutes
                                          {groupBy !== 'day' && ` (avg. per day)`}
                                        </>
                                      );
                                    })()}
                                  </>
                                )}
                              </Typography>
                            </Paper>
                          </Grid>
                          <Grid item xs={12} md={4}>
                            <Paper sx={{ p: 2, bgcolor: 'background.paper', borderLeft: '4px solid', borderColor: 'warning.main' }}>
                              <Typography variant="subtitle1" gutterBottom>Weekend vs. Weekday</Typography>
                              <Typography variant="body2" paragraph>
                                {occupancyData.day_of_week_distribution && (
                                  <>
                                    {(() => {
                                      const weekdayAvg = (
                                        occupancyData.day_of_week_distribution.Monday +
                                        occupancyData.day_of_week_distribution.Tuesday +
                                        occupancyData.day_of_week_distribution.Wednesday +
                                        occupancyData.day_of_week_distribution.Thursday +
                                        occupancyData.day_of_week_distribution.Friday
                                      ) / 5;
                                      
                                      const weekendAvg = (
                                        occupancyData.day_of_week_distribution.Saturday +
                                        occupancyData.day_of_week_distribution.Sunday
                                      ) / 2;
                                      
                                      return (
                                        <>
                                          <strong>Weekdays</strong>: {weekdayAvg.toFixed(1)} min/day
                                          <br />
                                          <strong>Weekends</strong>: {weekendAvg.toFixed(1)} min/day
                                          <br />
                                          <strong>Difference</strong>: {Math.abs(weekdayAvg - weekendAvg).toFixed(1)} min
                                        </>
                                      );
                                    })()}
                                  </>
                                )}
                              </Typography>
                            </Paper>
                          </Grid>
                        </Grid>
                      </Card>
                    </Grid>
                  </Grid>
                </>
              )}
            </>
          )}
        </div>
      </Container>
    </ThemeProvider>
  );
}

// Helper function to get current date in YYYY-MM-DD format
function getCurrentDate() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Helper function to get date X days ago in YYYY-MM-DD format
function getDateXDaysAgo(daysAgo) {
  const date = new Date();
  date.setDate(date.getDate() - daysAgo);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}