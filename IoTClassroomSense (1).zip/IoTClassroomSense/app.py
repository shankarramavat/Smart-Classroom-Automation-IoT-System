import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize extensions - these are imported by other modules
db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'warning'

def create_app():
    """Create and configure Flask application."""
    app = Flask(__name__, template_folder='templates', static_folder='static')
    
    # Configure app
    app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev_key_for_classroom_automation")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    
    # Initialize extensions with app
    db.init_app(app)
    login_manager.init_app(app)
    
    # Import models and define user loader
    with app.app_context():
        from models import User
        
        @login_manager.user_loader
        def load_user(user_id):
            return User.query.get(int(user_id))
    
    # Register blueprints
    with app.app_context():
        from routes.main import main
        from routes.auth import auth
        from routes.api import api
        from routes.admin import admin
        
        app.register_blueprint(main)
        app.register_blueprint(auth, url_prefix='/auth')
        app.register_blueprint(api, url_prefix='/api')
        app.register_blueprint(admin, url_prefix='/admin')
    
    # Initialize database (create tables and initial data)
    with app.app_context():
        db.create_all()
        
        # Check if admin user exists, create one if not
        from models import User, SystemState
        if not User.query.filter_by(username="admin").first():
            admin_user = User(
                username="admin",
                email="admin@example.com",
                is_admin=True
            )
            admin_user.set_password("admin123")
            db.session.add(admin_user)
            
            # Create initial system state
            if not SystemState.query.first():
                state = SystemState()
                db.session.add(state)
                
            db.session.commit()
            logger.info("Created initial admin user and system state")
    
    return app