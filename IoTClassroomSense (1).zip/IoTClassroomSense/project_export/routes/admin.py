from functools import wraps
from flask import Blueprint, render_template, redirect, url_for, request, flash, abort
from flask_login import login_required, current_user
from app import db
from models import User, SystemState, Log, Sensor
import datetime

admin = Blueprint('admin', __name__)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)  # Forbidden
        return f(*args, **kwargs)
    return decorated_function

@admin.route('/')
@login_required
@admin_required
def admin_dashboard():
    """Admin dashboard page."""
    # Count total users
    user_count = User.query.count()
    
    # Count total logs
    log_count = Log.query.count()
    
    # Count total sensors
    sensor_count = Sensor.query.count()
    
    # Get system state
    state = SystemState.query.first()
    if not state:
        state = SystemState()
        db.session.add(state)
        db.session.commit()
    
    # Get latest logs
    logs = Log.query.order_by(Log.timestamp.desc()).limit(5).all()
    
    # Get latest users
    users = User.query.order_by(User.created_at.desc()).limit(5).all()
    
    return render_template(
        'admin/dashboard.html', 
        title='Admin Dashboard',
        user=current_user,
        user_count=user_count,
        log_count=log_count,
        sensor_count=sensor_count,
        system_state=state,
        logs=logs,
        users=users
    )

@admin.route('/users')
@login_required
@admin_required
def manage_users():
    """User management page."""
    users = User.query.all()
    return render_template('admin/users.html', title='Manage Users', user=current_user, users=users)

@admin.route('/users/create', methods=['GET', 'POST'])
@login_required
@admin_required
def create_user():
    """Create new user page."""
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        is_admin = 'is_admin' in request.form
        
        # Check if username exists
        user = User.query.filter_by(username=username).first()
        if user:
            flash('Username already exists.', 'danger')
            return redirect(url_for('admin.create_user'))
        
        # Check if email exists
        user = User.query.filter_by(email=email).first()
        if user:
            flash('Email already exists.', 'danger')
            return redirect(url_for('admin.create_user'))
        
        # Create new user
        new_user = User(
            username=username,
            email=email,
            is_admin=is_admin
        )
        new_user.set_password(password)
        
        db.session.add(new_user)
        db.session.commit()
        
        # Log user creation event
        log = Log(
            event_type='user_created',
            device='web_interface',
            details=f'Admin {current_user.username} created new user {username}',
            user_id=current_user.id
        )
        
        db.session.add(log)
        db.session.commit()
        
        flash('User created successfully!', 'success')
        return redirect(url_for('admin.manage_users'))
    
    return render_template('admin/create_user.html', title='Create User', user=current_user)

@admin.route('/users/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_user(id):
    """Edit user page."""
    user = User.query.get_or_404(id)
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        is_admin = 'is_admin' in request.form
        
        # Check if username changed and exists
        if username != user.username:
            existing_user = User.query.filter_by(username=username).first()
            if existing_user:
                flash('Username already exists.', 'danger')
                return redirect(url_for('admin.edit_user', id=id))
            
            user.username = username
        
        # Check if email changed and exists
        if email != user.email:
            existing_user = User.query.filter_by(email=email).first()
            if existing_user:
                flash('Email already exists.', 'danger')
                return redirect(url_for('admin.edit_user', id=id))
            
            user.email = email
        
        # Update password if provided
        if password:
            user.set_password(password)
        
        # Update admin status
        user.is_admin = is_admin
        
        db.session.commit()
        
        # Log user update event
        log = Log(
            event_type='user_updated',
            device='web_interface',
            details=f'Admin {current_user.username} updated user {username}',
            user_id=current_user.id
        )
        
        db.session.add(log)
        db.session.commit()
        
        flash('User updated successfully!', 'success')
        return redirect(url_for('admin.manage_users'))
    
    return render_template('admin/edit_user.html', title='Edit User', user=user)

@admin.route('/users/delete/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_user(id):
    """Delete user."""
    user = User.query.get_or_404(id)
    
    # Prevent deleting own account
    if user.id == current_user.id:
        flash('You cannot delete your own account.', 'danger')
        return redirect(url_for('admin.manage_users'))
    
    username = user.username
    
    db.session.delete(user)
    db.session.commit()
    
    # Log user deletion event
    log = Log(
        event_type='user_deleted',
        device='web_interface',
        details=f'Admin {current_user.username} deleted user {username}',
        user_id=current_user.id
    )
    
    db.session.add(log)
    db.session.commit()
    
    flash('User deleted successfully!', 'success')
    return redirect(url_for('admin.manage_users'))

@admin.route('/sensors')
@login_required
@admin_required
def manage_sensors():
    """Sensor management page."""
    sensors = Sensor.query.all()
    return render_template('admin/sensors.html', title='Manage Sensors', user=current_user, sensors=sensors)

@admin.route('/sensors/create', methods=['GET', 'POST'])
@login_required
@admin_required
def create_sensor():
    """Create new sensor page."""
    if request.method == 'POST':
        sensor_id = request.form.get('sensor_id')
        sensor_type = request.form.get('sensor_type')
        location = request.form.get('location')
        ip_address = request.form.get('ip_address')
        
        # Check if sensor ID exists
        sensor = Sensor.query.filter_by(sensor_id=sensor_id).first()
        if sensor:
            flash('Sensor ID already exists.', 'danger')
            return redirect(url_for('admin.create_sensor'))
        
        # Create new sensor
        new_sensor = Sensor(
            sensor_id=sensor_id,
            sensor_type=sensor_type,
            location=location,
            ip_address=ip_address,
            status='offline'
        )
        
        db.session.add(new_sensor)
        db.session.commit()
        
        # Log sensor creation event
        log = Log(
            event_type='sensor_created',
            device='web_interface',
            details=f'Admin {current_user.username} created new sensor {sensor_id}',
            user_id=current_user.id
        )
        
        db.session.add(log)
        db.session.commit()
        
        flash('Sensor created successfully!', 'success')
        return redirect(url_for('admin.manage_sensors'))
    
    return render_template('admin/create_sensor.html', title='Create Sensor', user=current_user)

@admin.route('/sensors/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_sensor(id):
    """Edit sensor page."""
    sensor = Sensor.query.get_or_404(id)
    
    if request.method == 'POST':
        sensor_id = request.form.get('sensor_id')
        sensor_type = request.form.get('sensor_type')
        location = request.form.get('location')
        ip_address = request.form.get('ip_address')
        status = request.form.get('status')
        
        # Check if sensor ID changed and exists
        if sensor_id != sensor.sensor_id:
            existing_sensor = Sensor.query.filter_by(sensor_id=sensor_id).first()
            if existing_sensor:
                flash('Sensor ID already exists.', 'danger')
                return redirect(url_for('admin.edit_sensor', id=id))
            
            sensor.sensor_id = sensor_id
        
        # Update sensor details
        sensor.sensor_type = sensor_type
        sensor.location = location
        sensor.ip_address = ip_address
        sensor.status = status
        
        db.session.commit()
        
        # Log sensor update event
        log = Log(
            event_type='sensor_updated',
            device='web_interface',
            details=f'Admin {current_user.username} updated sensor {sensor_id}',
            user_id=current_user.id
        )
        
        db.session.add(log)
        db.session.commit()
        
        flash('Sensor updated successfully!', 'success')
        return redirect(url_for('admin.manage_sensors'))
    
    return render_template('admin/edit_sensor.html', title='Edit Sensor', user=current_user, sensor=sensor)

@admin.route('/sensors/delete/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_sensor(id):
    """Delete sensor."""
    sensor = Sensor.query.get_or_404(id)
    
    sensor_id = sensor.sensor_id
    
    db.session.delete(sensor)
    db.session.commit()
    
    # Log sensor deletion event
    log = Log(
        event_type='sensor_deleted',
        device='web_interface',
        details=f'Admin {current_user.username} deleted sensor {sensor_id}',
        user_id=current_user.id
    )
    
    db.session.add(log)
    db.session.commit()
    
    flash('Sensor deleted successfully!', 'success')
    return redirect(url_for('admin.manage_sensors'))