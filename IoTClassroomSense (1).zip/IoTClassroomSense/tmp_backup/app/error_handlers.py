from flask import render_template

def register_error_handlers(app):
    """Register error handlers with the Flask app."""
    
    @app.errorhandler(404)
    def page_not_found(e):
        """404 page not found."""
        return render_template('error.html', error=e, title='Page Not Found', code=404), 404
        
    @app.errorhandler(500)
    def internal_server_error(e):
        """500 internal server error."""
        return render_template('error.html', error=e, title='Internal Server Error', code=500), 500
        
    @app.errorhandler(403)
    def forbidden(e):
        """403 forbidden."""
        return render_template('error.html', error=e, title='Forbidden', code=403), 403
        
    @app.errorhandler(401)
    def unauthorized(e):
        """401 unauthorized."""
        return render_template('error.html', error=e, title='Unauthorized', code=401), 401