from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.extensions import db
from app.models import SystemState, Log, Sensor

main = Blueprint('main', __name__)

@main.route('/')
def index():
    """Home page."""
    return render_template('index.html')

@main.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard."""
    # Get current system state
    state = SystemState.query.order_by(SystemState.id.desc()).first()
    
    # Get recent logs
    logs = Log.query.order_by(Log.timestamp.desc()).limit(10).all()
    
    # Get sensor data
    sensors = Sensor.query.all()
    
    return render_template(
        'dashboard.html',
        user=current_user,
        state=state,
        logs=logs,
        sensors=sensors
    )

def register_main_routes(app):
    """Register main routes with the Flask app."""
    app.register_blueprint(main)