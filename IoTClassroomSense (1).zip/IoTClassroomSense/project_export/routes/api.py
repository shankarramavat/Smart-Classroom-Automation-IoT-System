from flask import Blueprint, jsonify, request, abort
from flask_login import login_required, current_user
from sqlalchemy import desc
from app import db
from models import SystemState, Log, Sensor
import datetime
import json
import random

api = Blueprint('api', __name__)

@api.route('/status', methods=['GET'])
@login_required
def get_status():
    """Get system status."""
    state = SystemState.query.first()
    if not state:
        state = SystemState()
        db.session.add(state)
        db.session.commit()
    
    # Simulate real-time sensor readings
    state.temperature = round(random.uniform(20.0, 30.0), 1)
    state.humidity = round(random.uniform(40.0, 60.0), 1)
    
    # Random motion detection (20% chance)
    motion_detected = random.random() < 0.2
    state.motion_detected = motion_detected
    
    # If motion is detected, set room as occupied, but not vice versa
    # (room stays occupied for a while after motion stops)
    if motion_detected:
        state.is_occupied = True
    
    # Update energy and cost savings
    lights_saving = 0.1 if not state.lights_on else 0.0
    ac_saving = 0.5 if not state.ac_on else 0.0
    fan_saving = 0.05 if not state.fan_on else 0.0
    
    state.energy_saved += lights_saving + ac_saving + fan_saving
    state.cost_saved += (lights_saving + ac_saving + fan_saving) * 8.0  # 8 INR per kWh
    
    state.updated_at = datetime.datetime.utcnow()
    db.session.commit()
    
    return jsonify({
        'success': True,
        'data': {
            'lights_on': state.lights_on,
            'ac_on': state.ac_on,
            'fan_on': state.fan_on,
            'is_occupied': state.is_occupied,
            'temperature': state.temperature,
            'humidity': state.humidity,
            'motion_detected': state.motion_detected,
            'lights_override': state.lights_override,
            'ac_override': state.ac_override,
            'fan_override': state.fan_override,
            'energy_saved': round(state.energy_saved, 2),
            'cost_saved': round(state.cost_saved, 2),
            'updated_at': state.updated_at.strftime('%Y-%m-%d %H:%M:%S')
        }
    })

@api.route('/logs', methods=['GET'])
@login_required
def get_logs():
    """Get system logs."""
    limit = request.args.get('limit', 20, type=int)
    offset = request.args.get('offset', 0, type=int)
    
    logs = Log.query.order_by(desc(Log.timestamp)).limit(limit).offset(offset).all()
    
    logs_data = []
    for log in logs:
        user = log.user.username if log.user else 'System'
        logs_data.append({
            'id': log.id,
            'timestamp': log.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            'event_type': log.event_type,
            'device': log.device or 'N/A',
            'details': log.details or 'N/A',
            'user': user
        })
    
    return jsonify({
        'success': True,
        'data': logs_data,
        'total': Log.query.count()
    })

@api.route('/control/<string:device>', methods=['POST'])
@login_required
def override_control(device):
    """Manual override of device controls."""
    if device not in ['lights', 'ac', 'fan']:
        return jsonify({
            'success': False,
            'message': 'Invalid device specified'
        }), 400
    
    data = request.json
    if not data or 'action' not in data:
        return jsonify({
            'success': False,
            'message': 'Action not specified'
        }), 400
    
    action = data['action']
    if action not in ['on', 'off', 'auto']:
        return jsonify({
            'success': False,
            'message': 'Invalid action specified'
        }), 400
    
    state = SystemState.query.first()
    if not state:
        state = SystemState()
        db.session.add(state)
    
    device_map = {
        'lights': ('lights_on', 'lights_override'),
        'ac': ('ac_on', 'ac_override'),
        'fan': ('fan_on', 'fan_override')
    }
    
    status_field, override_field = device_map[device]
    
    # Set device override status
    if action == 'auto':
        setattr(state, override_field, False)
        # If returning to auto mode, set device status based on occupancy
        setattr(state, status_field, state.is_occupied)
    else:
        setattr(state, override_field, True)
        setattr(state, status_field, action == 'on')
    
    # Log the action
    log = Log(
        event_type=f'{device}_control',
        device=device,
        details=f'Manual {action} command issued for {device}',
        user_id=current_user.id
    )
    
    db.session.add(log)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': f'{device.capitalize()} set to {action}',
        'data': {
            'device': device,
            'status': getattr(state, status_field),
            'override': getattr(state, override_field),
            'action': action
        }
    })

@api.route('/sensors', methods=['GET'])
@login_required
def get_sensors():
    """Get IoT sensor data."""
    sensors = Sensor.query.all()
    
    # If no sensors found, create some dummy sensors for demonstration
    if not sensors:
        demo_sensors = [
            Sensor(
                sensor_id='temp001',
                sensor_type='temperature',
                location='Main Classroom',
                ip_address='192.168.1.101',
                status='online',
                last_reading=24.5,
                last_reading_unit='°C',
                last_updated=datetime.datetime.utcnow()
            ),
            Sensor(
                sensor_id='hum001',
                sensor_type='humidity',
                location='Main Classroom',
                ip_address='192.168.1.102',
                status='online',
                last_reading=45.0,
                last_reading_unit='%',
                last_updated=datetime.datetime.utcnow()
            ),
            Sensor(
                sensor_id='mot001',
                sensor_type='motion',
                location='Main Classroom Door',
                ip_address='192.168.1.103',
                status='online',
                last_reading=0,
                last_reading_unit='boolean',
                last_updated=datetime.datetime.utcnow()
            ),
            Sensor(
                sensor_id='cam001',
                sensor_type='camera',
                location='Main Classroom Front',
                ip_address='192.168.1.104',
                status='online',
                last_updated=datetime.datetime.utcnow()
            )
        ]
        
        for sensor in demo_sensors:
            db.session.add(sensor)
        
        db.session.commit()
        sensors = demo_sensors
    
    # Update sensor readings with simulated data
    for sensor in sensors:
        if sensor.sensor_type == 'temperature':
            sensor.last_reading = round(random.uniform(20.0, 30.0), 1)
        elif sensor.sensor_type == 'humidity':
            sensor.last_reading = round(random.uniform(40.0, 60.0), 1)
        elif sensor.sensor_type == 'motion':
            sensor.last_reading = 1 if random.random() < 0.2 else 0
        
        sensor.last_updated = datetime.datetime.utcnow()
    
    db.session.commit()
    
    sensor_data = []
    for sensor in sensors:
        sensor_data.append({
            'id': sensor.id,
            'sensor_id': sensor.sensor_id,
            'sensor_type': sensor.sensor_type,
            'location': sensor.location,
            'ip_address': sensor.ip_address,
            'status': sensor.status,
            'last_reading': sensor.last_reading,
            'last_reading_unit': sensor.last_reading_unit,
            'last_updated': sensor.last_updated.strftime('%Y-%m-%d %H:%M:%S') if sensor.last_updated else None
        })
    
    return jsonify({
        'success': True,
        'data': sensor_data
    })