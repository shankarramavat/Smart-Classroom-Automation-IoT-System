import { useState, useEffect } from 'react';
import Head from 'next/head';
import { 
  Container, 
  Grid, 
  Card, 
  CardContent, 
  Typography, 
  Box, 
  Button, 
  Switch, 
  FormControlLabel,
  CircularProgress,
  IconButton,
  Snackbar,
  Alert,
  Paper
} from '@mui/material';
import { 
  LightbulbOutlined, 
  AcUnit, 
  Air, 
  Person, 
  PersonOutlineOutlined, 
  Thermostat, 
  Opacity,
  Settings,
  AutoMode,
  PowerSettingsNew,
  Home
} from '@mui/icons-material';
import { ThemeProvider } from '@mui/material/styles';
import theme from '../styles/theme';
import axios from 'axios';
import { Line, Bar } from 'react-chartjs-2';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  PointElement, 
  LineElement, 
  BarElement,
  Title, 
  Tooltip, 
  Legend 
} from 'chart.js';

// Register Chart.js components
ChartJS.register(
  CategoryScale, 
  LinearScale, 
  PointElement, 
  LineElement, 
  BarElement,
  Title, 
  Tooltip, 
  Legend
);

export default function Dashboard() {
  // State for system status
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'info' });
  
  // State for occupancy history chart
  const [occupancyData, setOccupancyData] = useState({
    labels: [],
    datasets: [
      {
        label: 'Occupancy',
        data: [],
        borderColor: '#FF9933',
        backgroundColor: 'rgba(255, 153, 51, 0.2)',
        fill: true,
      },
    ],
  });
  
  // State for recent logs
  const [recentLogs, setRecentLogs] = useState([]);
  
  // State for simulation mode
  const [simulationMode, setSimulationMode] = useState(0);
  
  // Fetch system status
  const fetchStatus = async () => {
    try {
      const response = await axios.get('/api/status');
      setStatus(response.data);
      setLoading(false);
    } catch (err) {
      console.error('Error fetching status:', err);
      setError('Failed to load system status. Please check your connection.');
      setLoading(false);
    }
  };
  
  // Fetch recent logs
  const fetchLogs = async () => {
    try {
      const response = await axios.get('/api/logs?limit=10');
      setRecentLogs(response.data.logs);
    } catch (err) {
      console.error('Error fetching logs:', err);
    }
  };
  
  // Handle manual override of devices
  const handleOverride = async (device, state) => {
    try {
      await axios.post('/api/override', { device, state });
      fetchStatus(); // Refresh status after override
      setSnackbar({
        open: true,
        message: `${device.charAt(0).toUpperCase() + device.slice(1)} set to ${state === null ? 'auto' : state ? 'on' : 'off'} mode`,
        severity: 'success'
      });
    } catch (err) {
      console.error('Error setting override:', err);
      setSnackbar({
        open: true,
        message: 'Failed to set override',
        severity: 'error'
      });
    }
  };
  
  // Handle simulation mode change
  const handleSimulationChange = async (mode) => {
    try {
      await axios.post('/api/simulation', { mode });
      setSimulationMode(mode);
      fetchStatus(); // Refresh status after simulation change
      
      const modeNames = ["Random", "Always Empty", "Always Occupied", "Alternating"];
      setSnackbar({
        open: true,
        message: `Simulation mode set to: ${modeNames[mode]}`,
        severity: 'info'
      });
    } catch (err) {
      console.error('Error setting simulation mode:', err);
      setSnackbar({
        open: true,
        message: 'Failed to change simulation mode',
        severity: 'error'
      });
    }
  };
  
  // Close snackbar
  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };
  
  // Initialize and start polling for updates
  useEffect(() => {
    // Initial data fetch
    fetchStatus();
    fetchLogs();
    
    // Poll for updates every 5 seconds
    const statusInterval = setInterval(fetchStatus, 5000);
    const logsInterval = setInterval(fetchLogs, 10000);
    
    // Cleanup on unmount
    return () => {
      clearInterval(statusInterval);
      clearInterval(logsInterval);
    };
  }, []);
  
  // Update chart data when status changes
  useEffect(() => {
    if (status) {
      // Update simulation mode state
      setSimulationMode(status.system.simulation_mode);
      
      // Add new data point to occupancy chart
      const now = new Date();
      const timeStr = now.toLocaleTimeString();
      
      setOccupancyData(prevData => {
        const newLabels = [...prevData.labels, timeStr];
        const newData = [...prevData.datasets[0].data, status.occupancy ? 1 : 0];
        
        // Keep only the last 20 data points
        const maxDataPoints = 20;
        if (newLabels.length > maxDataPoints) {
          newLabels.shift();
          newData.shift();
        }
        
        return {
          labels: newLabels,
          datasets: [
            {
              ...prevData.datasets[0],
              data: newData,
            }
          ]
        };
      });
    }
  }, [status]);
  
  // Loading state
  if (loading) {
    return (
      <ThemeProvider theme={theme}>
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
          <CircularProgress size={60} />
          <Typography variant="h6" sx={{ ml: 2 }}>Loading dashboard...</Typography>
        </Box>
      </ThemeProvider>
    );
  }
  
  // Error state
  if (error) {
    return (
      <ThemeProvider theme={theme}>
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', flexDirection: 'column' }}>
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
          <Button variant="contained" onClick={() => { setLoading(true); fetchStatus(); }}>
            Retry
          </Button>
        </Box>
      </ThemeProvider>
    );
  }
  
  // Render the dashboard
  return (
    <ThemeProvider theme={theme}>
      <Head>
        <title>IoT Classroom Automation</title>
        <meta name="description" content="Smart Classroom Automation Dashboard" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Grid container spacing={3}>
          {/* Header */}
          <Grid item xs={12}>
            <Paper 
              elevation={3} 
              sx={{ 
                p: 3, 
                display: 'flex', 
                justifyContent: 'space-between', 
                borderRadius: '12px',
                background: 'linear-gradient(90deg, rgba(19,136,8,0.8) 0%, rgba(0,0,205,0.8) 50%, rgba(255,153,51,0.8) 100%)'
              }}
            >
              <Box>
                <Typography variant="h4" component="h1" gutterBottom>
                  <Home sx={{ mr: 1, verticalAlign: 'top' }} /> 
                  Smart Classroom Automation
                </Typography>
                <Typography variant="body1">
                  Real-time monitoring and control of classroom appliances
                </Typography>
              </Box>
              <Box>
                <Button 
                  variant="contained" 
                  color="secondary" 
                  startIcon={<Settings />}
                  href="/analytics"
                  sx={{ mr: 1 }}
                >
                  Analytics
                </Button>
                <Button 
                  variant="contained" 
                  color="primary" 
                  startIcon={<Settings />}
                  href="/logs"
                >
                  System Logs
                </Button>
              </Box>
            </Paper>
          </Grid>
          
          {/* System Status */}
          <Grid item xs={12} md={6}>
            <Card elevation={3} sx={{ borderRadius: '12px' }}>
              <CardContent>
                <Typography variant="h5" component="h2" gutterBottom>
                  Current Status
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                      <Box
                        sx={{
                          bgcolor: status?.occupancy ? 'success.main' : 'error.main',
                          width: 12,
                          height: 12,
                          borderRadius: '50%',
                          mr: 1
                        }}
                      />
                      <Typography>
                        {status?.occupancy ? (
                          <>
                            <Person sx={{ verticalAlign: 'middle', mr: 0.5 }} />
                            Occupied
                          </>
                        ) : (
                          <>
                            <PersonOutlineOutlined sx={{ verticalAlign: 'middle', mr: 0.5 }} />
                            Vacant
                          </>
                        )}
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                      <Box
                        sx={{
                          bgcolor: status?.sensors.motion_detected ? 'warning.main' : 'text.disabled',
                          width: 12,
                          height: 12,
                          borderRadius: '50%',
                          mr: 1
                        }}
                      />
                      <Typography>
                        {status?.sensors.motion_detected ? 'Motion Detected' : 'No Motion'}
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>

                <Typography variant="h6" component="h3" gutterBottom sx={{ mt: 3 }}>
                  Appliance Control
                </Typography>
                
                <Grid container spacing={2}>
                  {/* Lights Control */}
                  <Grid item xs={12} sm={4}>
                    <Card 
                      sx={{ 
                        p: 2, 
                        display: 'flex', 
                        flexDirection: 'column', 
                        alignItems: 'center',
                        bgcolor: status?.devices.lights.status ? 'rgba(255, 153, 51, 0.1)' : 'background.paper',
                        borderRadius: '8px'
                      }}
                    >
                      <LightbulbOutlined 
                        sx={{ 
                          fontSize: 40, 
                          color: status?.devices.lights.status ? 'primary.main' : 'text.disabled',
                          mb: 1
                        }} 
                      />
                      <Typography variant="h6">Lights</Typography>
                      <Typography 
                        variant="body2" 
                        color={status?.devices.lights.override ? 'warning.main' : 'text.secondary'}
                        sx={{ mb: 1 }}
                      >
                        {status?.devices.lights.override ? 'Manual Override' : 'Auto Control'}
                      </Typography>
                      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 1 }}>
                        <IconButton
                          size="small"
                          color={status?.devices.lights.override === true ? 'primary' : 'default'}
                          onClick={() => handleOverride('lights', true)}
                          sx={{ mx: 0.5 }}
                        >
                          <PowerSettingsNew />
                        </IconButton>
                        <IconButton
                          size="small"
                          color={status?.devices.lights.override === false ? 'error' : 'default'}
                          onClick={() => handleOverride('lights', false)}
                          sx={{ mx: 0.5 }}
                        >
                          <PowerSettingsNew />
                        </IconButton>
                        <IconButton
                          size="small"
                          color={status?.devices.lights.override === null ? 'success' : 'default'}
                          onClick={() => handleOverride('lights', null)}
                          sx={{ mx: 0.5 }}
                        >
                          <AutoMode />
                        </IconButton>
                      </Box>
                    </Card>
                  </Grid>
                  
                  {/* AC Control */}
                  <Grid item xs={12} sm={4}>
                    <Card 
                      sx={{ 
                        p: 2, 
                        display: 'flex', 
                        flexDirection: 'column', 
                        alignItems: 'center',
                        bgcolor: status?.devices.ac.status ? 'rgba(0, 0, 205, 0.1)' : 'background.paper',
                        borderRadius: '8px'
                      }}
                    >
                      <AcUnit 
                        sx={{ 
                          fontSize: 40, 
                          color: status?.devices.ac.status ? 'tertiary.main' : 'text.disabled',
                          mb: 1
                        }} 
                      />
                      <Typography variant="h6">AC</Typography>
                      <Typography 
                        variant="body2" 
                        color={status?.devices.ac.override ? 'warning.main' : 'text.secondary'}
                        sx={{ mb: 1 }}
                      >
                        {status?.devices.ac.override ? 'Manual Override' : 'Auto Control'}
                      </Typography>
                      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 1 }}>
                        <IconButton
                          size="small"
                          color={status?.devices.ac.override === true ? 'primary' : 'default'}
                          onClick={() => handleOverride('ac', true)}
                          sx={{ mx: 0.5 }}
                        >
                          <PowerSettingsNew />
                        </IconButton>
                        <IconButton
                          size="small"
                          color={status?.devices.ac.override === false ? 'error' : 'default'}
                          onClick={() => handleOverride('ac', false)}
                          sx={{ mx: 0.5 }}
                        >
                          <PowerSettingsNew />
                        </IconButton>
                        <IconButton
                          size="small"
                          color={status?.devices.ac.override === null ? 'success' : 'default'}
                          onClick={() => handleOverride('ac', null)}
                          sx={{ mx: 0.5 }}
                        >
                          <AutoMode />
                        </IconButton>
                      </Box>
                    </Card>
                  </Grid>
                  
                  {/* Fan Control */}
                  <Grid item xs={12} sm={4}>
                    <Card 
                      sx={{ 
                        p: 2, 
                        display: 'flex', 
                        flexDirection: 'column', 
                        alignItems: 'center',
                        bgcolor: status?.devices.fan.status ? 'rgba(19, 136, 8, 0.1)' : 'background.paper',
                        borderRadius: '8px'
                      }}
                    >
                      <Air 
                        sx={{ 
                          fontSize: 40, 
                          color: status?.devices.fan.status ? 'secondary.main' : 'text.disabled',
                          mb: 1
                        }} 
                      />
                      <Typography variant="h6">Fan</Typography>
                      <Typography 
                        variant="body2" 
                        color={status?.devices.fan.override ? 'warning.main' : 'text.secondary'}
                        sx={{ mb: 1 }}
                      >
                        {status?.devices.fan.override ? 'Manual Override' : 'Auto Control'}
                      </Typography>
                      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 1 }}>
                        <IconButton
                          size="small"
                          color={status?.devices.fan.override === true ? 'primary' : 'default'}
                          onClick={() => handleOverride('fan', true)}
                          sx={{ mx: 0.5 }}
                        >
                          <PowerSettingsNew />
                        </IconButton>
                        <IconButton
                          size="small"
                          color={status?.devices.fan.override === false ? 'error' : 'default'}
                          onClick={() => handleOverride('fan', false)}
                          sx={{ mx: 0.5 }}
                        >
                          <PowerSettingsNew />
                        </IconButton>
                        <IconButton
                          size="small"
                          color={status?.devices.fan.override === null ? 'success' : 'default'}
                          onClick={() => handleOverride('fan', null)}
                          sx={{ mx: 0.5 }}
                        >
                          <AutoMode />
                        </IconButton>
                      </Box>
                    </Card>
                  </Grid>

                  {/* Master Control */}
                  <Grid item xs={12}>
                    <Box sx={{ mt: 2, display: 'flex', justifyContent: 'center' }}>
                      <Button 
                        variant="contained" 
                        color="primary" 
                        sx={{ mx: 1 }}
                        onClick={() => handleOverride('all', true)}
                      >
                        All On
                      </Button>
                      <Button 
                        variant="contained" 
                        color="error" 
                        sx={{ mx: 1 }}
                        onClick={() => handleOverride('all', false)}
                      >
                        All Off
                      </Button>
                      <Button 
                        variant="contained" 
                        color="secondary" 
                        sx={{ mx: 1 }}
                        onClick={() => handleOverride('all', null)}
                      >
                        Auto Mode
                      </Button>
                    </Box>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
          
          {/* Environment Sensors */}
          <Grid item xs={12} md={6}>
            <Card elevation={3} sx={{ height: '100%', borderRadius: '12px' }}>
              <CardContent>
                <Typography variant="h5" component="h2" gutterBottom>
                  Environment Sensors
                </Typography>
                <Grid container spacing={3}>
                  {/* Temperature */}
                  <Grid item xs={12} sm={6}>
                    <Box className="sensor-reading">
                      <Thermostat sx={{ color: 'primary.main', fontSize: 40, mb: 1 }} />
                      <Typography variant="h6" gutterBottom>Temperature</Typography>
                      <Box sx={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <CircularProgress 
                          variant="determinate" 
                          value={Math.min(((status?.sensors.temperature - 15) / 30) * 100, 100)} 
                          size={120}
                          thickness={5}
                          sx={{ 
                            color: status?.sensors.temperature > 28 ? 'error.main' : 
                                  status?.sensors.temperature > 24 ? 'warning.main' : 'success.main',
                            position: 'absolute'
                          }}
                        />
                        <CircularProgress 
                          variant="determinate" 
                          value={100} 
                          size={120}
                          thickness={5}
                          sx={{ 
                            color: 'grey.300',
                            position: 'absolute',
                            opacity: 0.3
                          }}
                        />
                        <Box sx={{ position: 'absolute', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                          <Typography variant="h4" component="div">
                            {status?.sensors.temperature.toFixed(1)}
                          </Typography>
                          <Typography variant="caption" component="div" color="text.secondary">
                            °C
                          </Typography>
                        </Box>
                      </Box>
                      <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                        {status?.sensors.temperature < 18 ? 'Cold' : 
                         status?.sensors.temperature < 24 ? 'Comfortable' : 
                         status?.sensors.temperature < 28 ? 'Warm' : 'Hot'}
                      </Typography>
                    </Box>
                  </Grid>
                  
                  {/* Humidity */}
                  <Grid item xs={12} sm={6}>
                    <Box className="sensor-reading">
                      <Opacity sx={{ color: 'tertiary.main', fontSize: 40, mb: 1 }} />
                      <Typography variant="h6" gutterBottom>Humidity</Typography>
                      <Box sx={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <CircularProgress 
                          variant="determinate" 
                          value={status?.sensors.humidity} 
                          size={120}
                          thickness={5}
                          sx={{ 
                            color: status?.sensors.humidity > 70 ? 'error.main' : 
                                  status?.sensors.humidity < 30 ? 'warning.main' : 'info.main',
                            position: 'absolute'
                          }}
                        />
                        <CircularProgress 
                          variant="determinate" 
                          value={100} 
                          size={120}
                          thickness={5}
                          sx={{ 
                            color: 'grey.300',
                            position: 'absolute',
                            opacity: 0.3
                          }}
                        />
                        <Box sx={{ position: 'absolute', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                          <Typography variant="h4" component="div">
                            {status?.sensors.humidity.toFixed(0)}
                          </Typography>
                          <Typography variant="caption" component="div" color="text.secondary">
                            %
                          </Typography>
                        </Box>
                      </Box>
                      <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                        {status?.sensors.humidity < 30 ? 'Dry' : 
                         status?.sensors.humidity < 60 ? 'Comfortable' : 
                         status?.sensors.humidity < 70 ? 'Humid' : 'Very Humid'}
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
          
          {/* Occupancy Chart */}
          <Grid item xs={12} md={8}>
            <Card elevation={3} sx={{ borderRadius: '12px' }}>
              <CardContent>
                <Typography variant="h5" component="h2" gutterBottom>
                  Occupancy History
                </Typography>
                <Box sx={{ height: 300 }}>
                  <Line 
                    data={occupancyData} 
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      scales: {
                        y: {
                          min: 0,
                          max: 1,
                          ticks: {
                            stepSize: 1,
                            callback: value => value === 0 ? 'Vacant' : 'Occupied'
                          }
                        }
                      },
                      plugins: {
                        legend: {
                          display: false
                        },
                        tooltip: {
                          callbacks: {
                            label: (context) => {
                              return context.raw === 0 ? 'Vacant' : 'Occupied';
                            }
                          }
                        }
                      }
                    }}
                  />
                </Box>
              </CardContent>
            </Card>
          </Grid>
          
          {/* Simulation Control */}
          <Grid item xs={12} md={4}>
            <Card elevation={3} sx={{ borderRadius: '12px' }}>
              <CardContent>
                <Typography variant="h5" component="h2" gutterBottom>
                  Simulation Control
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  Adjust the detection simulation mode for testing the system behavior.
                </Typography>
                
                <Grid container spacing={1}>
                  <Grid item xs={12}>
                    <Button 
                      fullWidth
                      variant={simulationMode === 0 ? "contained" : "outlined"}
                      color="primary"
                      onClick={() => handleSimulationChange(0)}
                      sx={{ mb: 1 }}
                    >
                      Random
                    </Button>
                  </Grid>
                  <Grid item xs={12}>
                    <Button 
                      fullWidth
                      variant={simulationMode === 1 ? "contained" : "outlined"}
                      color="error"
                      onClick={() => handleSimulationChange(1)}
                      sx={{ mb: 1 }}
                    >
                      Always Empty
                    </Button>
                  </Grid>
                  <Grid item xs={12}>
                    <Button 
                      fullWidth
                      variant={simulationMode === 2 ? "contained" : "outlined"}
                      color="success"
                      onClick={() => handleSimulationChange(2)}
                      sx={{ mb: 1 }}
                    >
                      Always Occupied
                    </Button>
                  </Grid>
                  <Grid item xs={12}>
                    <Button 
                      fullWidth
                      variant={simulationMode === 3 ? "contained" : "outlined"}
                      color="info"
                      onClick={() => handleSimulationChange(3)}
                    >
                      Alternating
                    </Button>
                  </Grid>
                </Grid>
                
                <Box sx={{ mt: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    System Uptime: {status ? formatUptime(status.system.uptime) : '0:00:00'}
                  </Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
          
          {/* Recent Events */}
          <Grid item xs={12}>
            <Card elevation={3} sx={{ borderRadius: '12px' }}>
              <CardContent>
                <Typography variant="h5" component="h2" gutterBottom>
                  Recent Events
                </Typography>
                {recentLogs.length > 0 ? (
                  <Box sx={{ maxHeight: '200px', overflowY: 'auto' }}>
                    {recentLogs.map((log) => (
                      <Box 
                        key={log.id} 
                        sx={{ 
                          p: 1, 
                          mb: 1, 
                          borderLeft: '3px solid', 
                          borderColor: getEventColor(log.event),
                          bgcolor: 'background.paper',
                          borderRadius: '4px'
                        }}
                      >
                        <Typography variant="body2" color="text.secondary">
                          [{new Date(log.timestamp * 1000).toLocaleTimeString()}]
                        </Typography>
                        <Typography variant="body1">
                          {log.event}: {log.details}
                        </Typography>
                      </Box>
                    ))}
                  </Box>
                ) : (
                  <Typography variant="body1" color="text.secondary">
                    No recent events to display
                  </Typography>
                )}
              </CardContent>
            </Card>
          </Grid>
        </Grid>
        
        {/* Snackbar for notifications */}
        <Snackbar 
          open={snackbar.open} 
          autoHideDuration={6000} 
          onClose={handleCloseSnackbar}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert 
            onClose={handleCloseSnackbar} 
            severity={snackbar.severity} 
            sx={{ width: '100%' }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Container>
    </ThemeProvider>
  );
}

// Helper function to format uptime
function formatUptime(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Helper function to get event color
function getEventColor(event) {
  switch (event) {
    case 'occupancy_detected':
      return '#66BB6A'; // Green
    case 'occupancy_lost':
      return '#FF5252'; // Red
    case 'appliance_on':
      return '#42A5F5'; // Blue
    case 'appliance_off':
      return '#78909C'; // Gray
    case 'manual_override':
      return '#FFB74D'; // Orange
    case 'simulation':
      return '#BA68C8'; // Purple
    default:
      return '#90A4AE'; // Light Gray
  }
}