import threading
import time
import random
import logging
import numpy as np
try:
    import cv2
except ImportError:
    # Mock cv2 for environments where it's not available
    cv2 = None

from app import db
from models import SystemState, Log

logger = logging.getLogger(__name__)

class OccupancyDetector(threading.Thread):
    """
    A class that detects occupancy in a classroom using computer vision.
    Uses OpenCV with a pre-trained MobileNet SSD model for person detection.
    """
    
    def __init__(self, camera_simulation, detection_interval=1.0):
        """
        Initialize the occupancy detector.
        
        Args:
            camera_simulation: CameraSimulation object that provides frames
            detection_interval: How often to perform detection in seconds
        """
        threading.Thread.__init__(self)
        self.daemon = True
        self.camera_simulation = camera_simulation
        self.detection_interval = detection_interval
        self.running = False
        self.occupied = False
        self.current_frame = None
        self.current_frame_with_detection = None
        
        # Pretend to load the model for demo purposes
        logger.info("Loading MobileNet SSD model...")
        self.net = MockSSDNet()
        
        # In a real system, we would load the OpenCV DNN model as follows:
        # self.net = cv2.dnn.readNetFromCaffe(
        #     "MobileNetSSD_deploy.prototxt.txt",
        #     "MobileNetSSD_deploy.caffemodel"
        # )
        
        # Define the classes the model can detect (only using person for this app)
        self.classes = ["background", "aeroplane", "bicycle", "bird", "boat",
                        "bottle", "bus", "car", "cat", "chair", "cow", "diningtable",
                        "dog", "horse", "motorbike", "person", "pottedplant", "sheep",
                        "sofa", "train", "tvmonitor"]
        
        # Initialize a few variables
        self.detection_start_time = time.time()
        
    def run(self):
        """Main detection loop that runs in a separate thread."""
        self.running = True
        logger.info("Starting occupancy detection...")
        
        # Main loop - keep running until stopped
        while self.running:
            # Get a frame from the camera
            frame = self.camera_simulation.get_frame()
            self.current_frame = frame.copy()
            
            # Detect people
            occupied = self.detect_people(frame)
            
            # If occupancy state changed, log it
            if occupied != self.occupied:
                self.occupied = occupied
                
                # Update the system state in the database
                with db.app.app_context():
                    system_state = SystemState.query.order_by(SystemState.timestamp.desc()).first()
                    if not system_state:
                        system_state = SystemState()
                        db.session.add(system_state)
                    
                    system_state.occupancy = occupied
                    system_state.timestamp = time.time()
                    
                    log_entry = Log(
                        event=f"OCCUPANCY_{'DETECTED' if occupied else 'ENDED'}",
                        details=f"Room is {'occupied' if occupied else 'empty'}"
                    )
                    db.session.add(log_entry)
                    db.session.commit()
                
                logger.info(f"Occupancy changed: Room is {'occupied' if occupied else 'empty'}")
            
            # Sleep for the detection interval
            time.sleep(self.detection_interval)
    
    def detect_people(self, frame):
        """
        Detect people in a frame using the MobileNet SSD model.
        
        Args:
            frame: The image frame to analyze
            
        Returns:
            bool: True if at least one person is detected, False otherwise
        """
        try:
            # Create a 300x300 blob from the frame
            blob = cv2.dnn.blobFromImage(
                cv2.resize(frame, (300, 300)),
                0.007843, (300, 300), 127.5
            )
            
            # Pass the blob through the network
            detections = self.net.detect(blob)
            
            # Reset the output image
            output_frame = frame.copy()
            
            # Extract the results
            # In a real system, we would process detections from the model
            person_detected = False
            height, width = frame.shape[:2]
            
            # In our mock simulation, detections is just a list of (class_id, confidence, box)
            for detection in detections:
                class_id, confidence, box = detection
                
                if confidence > 0.5 and self.classes[class_id] == "person":
                    person_detected = True
                    
                    # Draw a rectangle around the person
                    (left, top, right, bottom) = box
                    left = int(left * width)
                    top = int(top * height)
                    right = int(right * width)
                    bottom = int(bottom * height)
                    
                    cv2.rectangle(
                        output_frame,
                        (left, top),
                        (right, bottom),
                        (0, 255, 0), 2
                    )
                    
                    # Add a label
                    cv2.putText(
                        output_frame,
                        f"Person: {confidence:.2f}",
                        (left, top - 10),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5, (0, 255, 0), 2
                    )
            
            # Update the frame with detection
            self.current_frame_with_detection = output_frame
            
            return person_detected
            
        except Exception as e:
            logger.error(f"Error in people detection: {e}")
            return False
    
    def get_current_frame(self):
        """Get the current processed frame for the dashboard."""
        if self.current_frame_with_detection is not None:
            return self.current_frame_with_detection
        return self.current_frame if self.current_frame is not None else None
    
    def is_occupied(self):
        """Return whether the classroom is currently occupied."""
        return self.occupied
    
    def stop(self):
        """Stop the detection thread."""
        self.running = False

class MockSSDNet:
    """
    A mock class to simulate the OpenCV DNN SSD network for person detection.
    Used for testing in Replit environment.
    """
    def __init__(self):
        self.mode = 0  # 0 = random, 1 = always detect, 2 = never detect
    
    def detect(self, blob):
        """
        Simulate detection based on the simulation mode.
        
        Args:
            blob: The input blob (not used)
            
        Returns:
            np.ndarray: Simulated detection results
        """
        # Generate a random detection result
        if self.mode == 0:
            # 70% chance of detecting a person
            if random.random() < 0.7:
                return [
                    (15, 0.95, (0.2, 0.2, 0.8, 0.9))  # class_id, confidence, box
                ]
            else:
                return []
        elif self.mode == 1:
            # Always detect a person
            return [
                (15, 0.95, (0.2, 0.2, 0.8, 0.9))  # class_id, confidence, box
            ]
        else:
            # Never detect a person
            return []
    
    def set_simulation_mode(self, mode):
        """
        Set the simulation mode.
        
        Args:
            mode: 0 for random, 1 for always detect, 2 for never detect
        """
        self.mode = mode